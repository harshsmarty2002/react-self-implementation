
import { React, useReducer } from "react";
import './Functions.css';

const initialState = 0;

const reducer = (state, action) => {
    console.log(state,action);
    if(action.type==="INCREMENT")

    return state+1;
    if(action.type==="DECRIMENT")
    return state -1
}
const use = () => {
    const [state, dispatch] = useReducer(reducer, initialState);
    
    return (

        <div className="center">
            <p>{state}</p>
            <button onClick={() => dispatch({type: "INCREMENT"})} className="btn btn-primary">Increment</button><br />
            <button onClick={() => dispatch({type: "DECREMENT"})} className="btn btn-warning">Decrement</button>

        </div>
    );
}
export default use;