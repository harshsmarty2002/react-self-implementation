import React from "react";
import { useReducer } from "react";


const reducer=(state,action)=>
{
    // console.log(state,action);
    if(action.type==="INCREMENT")
    {
        return state+1;
    }
    if(action.type==="DECREMENT")
    {
        return state-1;
    }
    
}
const Reducer2=()=>
{
    const initialState=0;
  
    const [state,dispatch]=useReducer(reducer,initialState);
    
    return(
     
        <>
        <p>{state}</p>
        <button onClick={()=>dispatch({
            type:"INCREMENT",
            })} className="btn btn-primary">increase</button>
        <button onClick={()=>dispatch({
            type:"DECREMENT",
            
        })} className="btn btn-warning">decrease</button>
        
        </>
    );

}
export default Reducer2;