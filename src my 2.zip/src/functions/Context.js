import React from "react";
import { createContext } from "react";
const MyContext=createContext();
const Coder1=()=>
{
    return <Code2 />
}
const Code2=()=>
{
    return <Code3 />
}
const Code3=()=>
{
    return (

        <MyContext.Consumer>
            {
                (data)=>{
                   return <h1>Hello I am a {data}</h1>
                }
            }
          
        </MyContext.Consumer>
    )

}
function Context()
{
    return(
        <MyContext.Provider value="Harsh">

            <div>
                <Code3 />
            </div>
        </MyContext.Provider>
        
    );

}
export default Context;