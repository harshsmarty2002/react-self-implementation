import {ActionType} from './ActionType';
//addToCart if a action function 
export const addToCart=(data)=>
{
    console.log("action");
    return {
        type:ActionType.ADD_TO_CART,
        payload:data 
    }
}

export const removeToCart=(data)=>
{
    console.log("action");
    return{
        type:ActionType.REMOVE_TO_CART,
        payload:data
    }
}