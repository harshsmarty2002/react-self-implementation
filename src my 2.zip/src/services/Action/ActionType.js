export const ActionType={
    ADD_TO_CART:'ADD_TO_CART',
    REMOVE_TO_CART:'REMOVE_TO_CART'
}