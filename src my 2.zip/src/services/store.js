import root from './reducer/index';
import {createStore} from 'redux';
const store=createStore(root);
export default store;

