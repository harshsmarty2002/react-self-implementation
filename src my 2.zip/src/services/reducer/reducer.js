import {ActionType} from '../Action/ActionType';

const initialState={
    cartData:[],
    removedData:[]
};
//cartItems It is a reducer function
export const cart_items=(state=initialState,{type,payload})=>{
    switch(type){
        case ActionType.ADD_TO_CART:
            return{
                ...state,
                cartData:payload 
            }
        case ActionType.REMOVE_TO_CART:
            {
                return {
                    ...state,
                    removedData:payload
                }
            }
            default:
                return state;
    }
}