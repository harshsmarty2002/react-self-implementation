import { combineReducers } from "redux";
import {cart_items} from './reducer';
export default combineReducers({cart_items});
