import React from "react";
import { Axios } from "axios";
function Example1()
{
    const var async=()=>
    {
        const 
    }
    return(
        <>
        <div>Hello Harsh You Are in div</div>
        </>
    );
}
export default Example1;