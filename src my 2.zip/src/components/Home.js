import React from "react";
import '../App.css';
import Laptop from '../laptop.jpg';
import Cart from '../cart.jpg';
// import mobile from '../mobile.jpg';
const Home = () => {
    return (
        <div className="container">
            <div id="cart" >
            <img alt="Show Items here" src={Cart}/>
            </div>
            <div className="dd">
          
               <img id="laptop" src={Laptop} />
                <button onClick={()=>props.addToCartHandler({price:1000,name:'harsh'})} className="btn btn-primary">Add to cart</button>
              
                
                {/* <label>Show Items Here</label> */}
               
            </div>

            {/* <div className="dd2">
           
          
                <img src={mobile} />
            </div> */}
        </div>
    );

}
export default Home;