import {connect} from 'react-redux';
import Home from '../components/Home';
import {addToCart} from '../services/Action/actions';

// const mapStateToProps=state=>({
//     addToCartHandler:data=>dispatchEvent(addToCart(data))
    
// })
// console.log(state);
// const mapDispatchToProps=state=>({

// })
export default Home;
// export default connect(mapDispatchToProps,mapStateToProps)(Home);
// const mapStateToprops=function state({})
// export default Home;