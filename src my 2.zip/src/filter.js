// const arr=[1,2,3,4,5,6];
// const arr2=[10,11,13,14,...arr,'harsh','Saini'];
// console.log(arr2);

// import { computeHeadingLevel } from "@testing-library/react";

const fruit=["A","V","I","Y"];
const ne=fruit.toString();
console.log(ne);
console.log(fruit);


const no=fruit.sort();   //sorted Array
console.log(no);


const anamikaowl=no.reverse();  //reverse sorted Array elements
console.log(anamikaowl);




// const arr=[{
//     Name:'harsh',
//     Mobile:9012211950,
//     DOB:26-04-2001

// }]
// const combine=arr.reducer();
// console.log(combine);
