import React, { useEffect } from "react";
import { useState } from "react";
import './simple.css';

class Posting {
    constructor(eid, name, designation, doa, salary, mobile, photo) {
        this.eid = eid;
        this.name = name;
        this.designation = designation;
        this.doa = doa;
        this.salary = salary;
        this.mobile = mobile;
        this.photo = photo;

    }

}


function Simple() {

    let [eid, setEid] = useState("");
    let [name, setName] = useState("");
    let [designation, setDesignation] = useState("");
    let [salary, setSalary] = useState("");
    let [doa, setDoa] = useState("");
    let [mobile, setMobile] = useState("");
    let [photo, setPhoto] = useState("");

    function api() {

        fetch("https://api.webroot.net.in/employees.php?eid=" + eid).then((response) => response.json()).then(result => {
            if (result.status == 'Empty') {
                alert("Data Not Found");
                setEid("");
                setName("");
                setDesignation("");
                setSalary("");
                setDoa("");
                setMobile("");
                setPhoto("");


            }
            else {
                setEid(result.eid);
                setName(result.name);
                setDesignation(result.designation);
                setSalary(result.salary);
                setDoa(result.doa);
                setMobile(result.mobile);
                setPhoto(result.photo);


            }
        });

    }
    function api2() {
        let obj = new Posting(eid, name, designation, doa, salary, mobile, photo);
        let str = JSON.stringify(obj);
        // let http={method:"POST" ,body:str}
       
       
        
        fetch("https://api.webroot.net.in/employees.php?opr=U&eid=" + eid,
        {
            method : "POST",
            headers:{
                'Accept' : 'appliction/json',
                'Content-Type':'appclication/json'},
            body: JSON.stringify(obj)
        } ).then((response) => response.json()).then(result => {
            if (result.status == "Error") {
                console.log(result);
                alert("Something wents Wrong Data Not Found");
            }
            else {
                alert("Data Updated Successfully");
                setEid("");
                setName("");
                setDesignation("");
                setSalary("");
                setDoa("");
                setMobile("");
                setPhoto("");



            }
        });
    }
    

    function api32() {
        fetch("https://api.webroot.net.in/employees.php?opr=D&eid=" + eid,
        {
            method: "post"
        }).then((response) => response.json()).then(result => {
            console.log(result);
            if (result.status == "OK") {
                alert("Data Deleted Successfully");
            }
            else{
                alert("Error");
            }


        });


    }





    useEffect(() => { api(); }, []);

    return (
        <>
            <div className="row">
                <div className="col-lg-1"></div>
                <div className="col-lg-4">
                    <div className="row form-group">
                        <div>
                            <label>Employee Id</label>
                            <input type="text" onChange={(e) => { setEid(e.target.value) }} placeholder="Enter a Employee Id" className="form-control" />
                        </div>
                        <div>
                            <label>Name</label>
                            <input type="text" onChange={(e) => { setName(e.target.value) }} value={name} className="form-control" />
                        </div>
                        <div>
                            <label>Designation</label>
                            <input type="text" onChange={(e) => { setDesignation(e.target.value) }} value={designation} className="form-control" />
                        </div>
                        <div>
                            <label>Salary</label>
                            <input type="text" onChange={(e) => { setSalary(e.target.value) }} value={salary} className="form-control" />
                        </div>
                        <div>
                            <label>DOA</label>
                            <input type="text" onChange={(e) => { setDoa(e.target.value) }} value={doa} className="form-control" />
                        </div>
                        <div>
                            <label>Mobile</label>
                            <input type="text" onChange={(e) => { setMobile(e.target.value) }} value={mobile} className="form-control" />
                        </div>
                        <div>
                            <label>Photo</label>
                            <input type="text" onChange={(e) => { setPhoto(e.target.value) }} value={photo} className="form-control" />
                        </div>
                        <div id="btn">
                            <button className="btn btn-primary btn-block" onClick={api}>Search</button>
                            <button className="btn btn-success btn-block" onClick={api2}>Update</button>
                            <button className="btn btn-danger btn-block" onClick={api32} >Delete</button>
                            <button className="btn btn-warning btn-block">Clear</button>
                        </div>
                    </div>

                </div>
                <div className="col-lg-1"></div>
                <div className="col-lg-6">
                    <div className="row form-group">
                        <div className="col-lg-1"></div>
                        <div className="col-lg-4" id="second">
                            <div>
                                <label>Hello </label>
                                <textarea placeholder="Enter Name Here" className="form-control" />

                            </div>

                        </div>
                        <div className="col-lg-1"></div>
                    </div>
                </div>

            </div>

        </>

    );
}
export default Simple;