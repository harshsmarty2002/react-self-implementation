import React, {useState} from 'react';
import axios from 'axios';
import {useNavigate} from 'react-router-dom';
// import "./custom.css";
// import "./media.css";

const Admin_login = () => {
    const navigate = useNavigate();
    const [formdata, setFormdata] = useState({ amit: '',india: ''})
    const [passwordType, setPasswordType] = useState("password");
    const [errors, setErrors] = useState({})
    const [notregister, setNoregister] = useState(null)
    const [isloader, setIsloader] = useState(false)
     
    const handleChange = (e) => {
        if (e.target.name == "amit") {
            errors.User_error = undefined;
            setNoregister(null)
        }
        if (e.target.name =="india") {
            errors.user_password_error = undefined;
            setNoregister(null)
        }
        setFormdata((formdata) => ({...formdata, [e.target.name]: e.target.value}))
    }
    const togglePassword =()=>{
        if(passwordType==="password")
        {
         setPasswordType("text")
         return;
        }
        setPasswordType("password")
      }

    const LoginForm = async (e) => {
        e.preventDefault();
        const formData = {
            amit: formdata.amit,
            india: formdata.india
        }
        if (Validate()) {
            
            setIsloader(true)
            axios.post(process.env.REACT_APP_API + 'AccountPost/admin_login', formData, {
                headers: {
                    "Content-Type": "application/json"
                }
            })
                .then(res => {

                    if (res.data.status == "userid_do_not_exist") {
                        setNoregister('Your user name is not register')
                    }
                    else if (res.data.status == "invalid_password") {
                        setNoregister('Wrong Password');
                    }
                    else if (res.data.status=="Your account is deactivate"){
                        setNoregister('Your account is deactivate');
                    }
                    else if (res.data.status=="trial period is expired"){
                        setNoregister('trial period is expired');
                    }
                    else {
                        localStorage.setItem('Admin_Data', JSON.stringify(res.data.value))
                        setIsloader(false)
                        navigate('/register')
                    }

                    setIsloader(false)
                }).catch(err => {

                console.log(err.errors)
            })
        }
    }

    
    function Validate() {

        let error = {};
        let validate = true;
            if (!formdata.amit) {
                validate = false;
                error["User_error"] = "Please Enter User Name";
                
            }
            if (!formdata.india) {
                validate = false;
                error["user_password_error"] = "Please Enter Password";
            }
        setErrors(error)
        return validate;
    }
    const handleKeyDown = e => {
        if (e.key === " ") {
          e.preventDefault();
        }
      };
    return (
        <>
            <div class="login">
                <div class="row g-0">
                    <div class="col-lg-6 position-relative">
                        <div class="login-form">
                            <div class="company_logo text-center">
                                <img src="/image/unibill-logo-final-sending.png"/>
                            </div>
                            <div class="login_heading">
                                <h2>Log in</h2>
                                <p>Please log in or sign up for an account</p>
                            </div>
                            <div class="login_input">
                                <form method="post" onSubmit={LoginForm}>
                                        <div class="form-group">
                                            <label><i class="icofont-ui-user"></i> User name.</label>
                                            <div class="custom_input position-relative">
            
                                                <input type="text" onKeyDown={handleKeyDown}  class="form-control" name="amit" value={formdata.amit} onChange={handleChange} placeholder="Enter User Name"/>
                                                <span class="number_input"><i class="icofont-ui-user"></i></span>
                                            </div>
                                            {errors.User_error && <div class="error_msg">{errors.User_error}</div>}
                                        </div>
                                        <div class="form-group">
                                            <label><i class="icofont-lock"></i> Password</label>
                                            <input type={passwordType} autoComplete="new-password" class="form-control" name="india" value={formdata.india} onChange={handleChange} placeholder="Enter Password"/>
                                           <span className='hide' onClick={togglePassword}>
                                            { passwordType==="password"?   <i class="fa fa-eye-slash" aria-hidden="true"></i>: <i class="fa fa-eye" aria-hidden="true"></i>}
                                            </span>
                                           {errors.user_password_error && <div class="error_msg">{errors.user_password_error}</div>
                                            }
                                        </div>
                                        <div class="form-group">
                                            <button type='submit' class="btn w-100">{isloader ? '...Please Wait' : 'Log in'}</button>
                                            {notregister && <div class="error_msg">{notregister}</div>}
                                        </div>
                                </form>
                                <div class="form-group d-flex justify-content-between forgot_password mb-0">
                                    <div class="form-check">
                                        <input type="checkbox" class="form-check-input" id="exampleCheck1"/>
                                        <label class="form-check-label" for="exampleCheck1">Remember me</label>
                                    </div>
                                   
                                </div>
                            </div>
                          
                        </div>
                    </div>
                    <div class="col-lg-6 login_bg">
                        <div class="middle_login_img">
                            <img src="/image/MicrosoftTeams-image-left.png" class="img-fluid"/>
                        </div>
                        {/* <div class="bg_with_content position-relative">
				<h3>Start your free trial. No credit card required, no software to install.</h3>
				<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
				<ul>
					<li><i class="icofont-tick-mark"></i> Preloaded data or upload your own</li>
					<li><i class="icofont-tick-mark"></i> Preconfigured processes, reports, and dashboards</li>
					<li><i class="icofont-tick-mark"></i> Guided experiences for sales reps, leaders, and administrators</li>
					<li><i class="icofont-tick-mark"></i> Online training and live onboarding webinars</li>
				</ul>
				<div class="content-img"><img src="image/login-bg-1.png" class="img-fluid"/></div>
			</div>  */}
                    </div>
                </div>
            </div>

        </>
    )

}

export default Admin_login;