import React, {useState} from 'react';
import axios from 'axios';
import {useNavigate} from 'react-router-dom';
import Cookies from 'js-cookie';
import {Link} from 'react-router-dom';
import "../dashboard/components/css/custom.css";
import "../dashboard/components/css/media.css";


const Login = () => {
    const navigate = useNavigate();
    const [formdata, setFormdata] = useState({
        amit: '',
        india: '',
        
    })
    const [passwordType, setPasswordType] = useState("password");
    const [errors, setErrors] = useState({})
    const [notregister, setNoregister] = useState(null)
    const [isloader, setIsloader] = useState(false)
    const [radio, setradio] = useState({
        selectedOption:"Mobile"
    })
const radiobutton = (e)=>{
    setradio({
        selectedOption: e.target.value
      });
}

    const handleChange = (e) => {
        if (radio.selectedOption === "Mobile"){
            if (e.target.name == "amit") {
                if(e.target.value.length==11) return false; 
                errors.mobile_error = undefined;
                setNoregister(null)
       
    }
    if (e.target.name =="india") {
     errors.password_error = undefined;
     setNoregister(null)
    }
} 
if (radio.selectedOption === "User"){
    if (e.target.name == "amit") {
        errors.User_error= undefined;
        setNoregister(null)
    }
    if (e.target.name =="india") {
        errors.user_password_error = undefined;
        setNoregister(null)
    }

}  
        setFormdata((formdata) => ({...formdata, [e.target.name]: e.target.value}))
    }
    const togglePassword =()=>{
        if(passwordType==="password")
        {
         setPasswordType("text")
         return;
        }
        setPasswordType("password")
      }
    const LoginForm = async (e) => {
        e.preventDefault();
        const formData = {
            amit: formdata.amit,
            india: formdata.india,
            type:radio.selectedOption === "Mobile" ? 1 : 0,
           
        }
        if (Validate()) {
            setIsloader(true)
            axios.post(process.env.REACT_APP_API + 'AccountPost/Login', formData, {
                headers: {
                    "Content-Type": "application/json"
                }
            })
                .then(res => {

                    if (res.data.status == "userid_do_not_exist") {
                        radio.selectedOption === "Mobile" ?  setNoregister('Your number is not register'):setNoregister('Your user name is not register')

                    }
                    else if (res.data.status == "invalid_password") {

                        setNoregister('Wrong Password');
                    }
                    else if (res.data.status=="Your account is deactivate"){
                        setNoregister('Your account is deactivate');
                    }
                    else if (res.data.status=="trial period is expired"){
                        setNoregister('trial period is expired');
                    }
                    
                    else {
                      
                       // console.log('res', res)
                        Cookies.set('token', res.data.value.token);
                        Cookies.set('refreshToken', res.data.value.refreshToken);
                        Cookies.set('mid', res.data.value.mid)
                        Cookies.set('bid', res.data.value.bid)
                        Cookies.set('utype', res.data.value.utype)
                        localStorage.setItem('permission', JSON.stringify(res.data.value.permission))
                        setIsloader(false)
                        navigate('/dashboard')
                    }

                    setIsloader(false)
                }).catch(err => {

                console.log(err.errors)
            })
        }
    }


    function Validate() {

        let error = {};
        let validate = true;
       

        if (radio.selectedOption === "Mobile"){
            if (!formdata.amit) {
                validate = false;
                error["mobile_error"] = "Please Enter Mobile Number";
            }
        else  if (formdata.amit.length != 10) {
            validate = false;
            
            error["mobile_error"] = "Please Enter 10 digit No";
        }
        if (!formdata.india) {

            validate = false;
            error["password_error"] = "Please Enter Password";
        }
        }

        if (radio.selectedOption === "User"){
            if (!formdata.amit) {
                validate = false;
                error["User_error"] = "Please Enter User Name";
            }
            if (!formdata.india) {

                validate = false;
                error["user_password_error"] = "Please Enter Password";
            }
        
        }

       
       
        setErrors(error)
        return validate;

    }

    const blockInvalidChar = e => ['e', 'E', '+', '-','.'].includes(e.key) && e.preventDefault();
    const handleKeyDown = e => {
        if (e.key === " ") {
          e.preventDefault();
        }
      };

    return (
        <>
 
            <div class="login">
                <div class="row g-0">
               
                    <div class="col-lg-6 position-relative">
                 
                        <div class="login-form">
                        
                            <div class="company_logo text-center">
                            
                                <img src="/image/unibill-logo-final-sending.png"/>
                            </div>
                            <div class="login_heading">
                                <h2>Log in</h2>
                                <p>Please log in or sign up for an account</p>
                            </div>

                            <div class="login_input">
                            <div>
                            <div class="form-check form-check-inline">
  <input class="form-check-input" type="radio"   checked={radio.selectedOption === "Mobile" ? true :false} name="Mobile" id="Mobile" onChange={radiobutton} value="Mobile"/>
  <label class="form-check-label" for="Mobile"> With Mobile No</label>
</div>
<div class="form-check form-check-inline">
  <input class="form-check-input" type="radio" checked={radio.selectedOption === "User" ? true :false}  onChange={radiobutton} name="User" id="User" value="User"/>
  <label class="form-check-label" for="User"> With User Name</label>
</div>
</div>
                                <form method="post" onSubmit={LoginForm}>
                                    <>
                                    {radio.selectedOption === "Mobile" ?
                                        <div class="form-group">
                                            <label><i class="icofont-smart-phone"></i> Mobile no.</label>
                                            <div class="custom_input position-relative">
                                                <input type="number" min="0" onKeyDown={blockInvalidChar} value={formdata.amit} onWheel={() => document.activeElement.blur()}  class="form-control" name="amit" onChange={handleChange} placeholder="Enter Mobile Number"/>
                                                <span class="number_input">+91</span>
                                            </div>
                                            {errors.mobile_error && <div class="error_msg">{errors.mobile_error}</div>}
                                        </div>
                                        :
                                        <div class="form-group">
                                            <label><i class="icofont-ui-user"></i> User name.</label>
                                            <div class="custom_input position-relative">
                                                <input type="text" onKeyDown={handleKeyDown}  class="form-control" name="amit" onChange={handleChange} placeholder="Enter User Name"/>
                                                <span class="number_input"><i class="icofont-ui-user"></i></span>
                                            </div>
                                            {errors.User_error && <div class="error_msg">{errors.User_error}</div>}
                                        </div>
                                    }
                                        <div class="form-group">
                                            <label><i class="icofont-lock"></i> Password</label>
                                            <input type={passwordType} value={formdata.india} class="form-control" name="india" onChange={handleChange} placeholder="Enter Password"/>
                                         
                   
                                           <span className='hide' onClick={togglePassword}>
                                            { passwordType==="password"?   <i class="fa fa-eye-slash" aria-hidden="true"></i>: <i class="fa fa-eye" aria-hidden="true"></i>}
                                            </span>
                                            
                                            {radio.selectedOption === "Mobile" ?
                                            errors.password_error && <div class="error_msg">{errors.password_error}</div>:
                                            errors.user_password_error && <div class="error_msg">{errors.user_password_error}</div>
                                            }
                                        </div>
                                        <div class="form-group">
                                            <button type='submit' class="btn w-100">{isloader ? '...Please Wait' : 'Log in'}</button>
                                            {notregister && <div class="error_msg">{notregister}</div>}
                                        </div>
                                    </>
                                </form>
                                <div class="form-group d-flex justify-content-between forgot_password mb-0">
                                    <div class="form-check">
                                        <input type="checkbox" class="form-check-input" id="exampleCheck1"/>
                                        <label class="form-check-label" for="exampleCheck1">Remember me</label>
                                    </div>
                                    <Link to="/Forgot_password">Forgot password ?</Link>
                                </div>
                            </div>
                            <div class="not_register text-center mt-3">
                                <p>Not registered ? <Link to="/register" class="ms-3">Sign up</Link></p>
                            </div>
                        </div>
                    </div>
                  
                    <div class="col-lg-6 login_bg">
                    {isloader && 
                    <div style={{position: "fixed",top:"0",left: "0",right: "0",background: "rgb(254 253 253 / 85%)",height: "100%",zIndex: "9999"}}>
                    <img src="image/loader-gif.gif" class="position-absolute top-50 start-50 translate-middle" style={{maxHeight: "150px", transform: "translate(-50%, -50%)"}} alt="loading..." /></div>
                    }  
                    {/* {isloader && 
                    <img src="image/unifier-logo-gif.gif" class="position-absolute top-50 start-50 translate-middle" style={{maxHeight: "150px"}} alt="loading..." />}   */}
                        <div class="middle_login_img">
                       
                            <img src="/image/MicrosoftTeams-image-left.png" class="img-fluid"/>
                           
                        </div>
                        
                        {/* <div class="bg_with_content position-relative">
				<h3>Start your free trial. No credit card required, no software to install.</h3>
				<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
				<ul>
					<li><i class="icofont-tick-mark"></i> Preloaded data or upload your own</li>
					<li><i class="icofont-tick-mark"></i> Preconfigured processes, reports, and dashboards</li>
					<li><i class="icofont-tick-mark"></i> Guided experiences for sales reps, leaders, and administrators</li>
					<li><i class="icofont-tick-mark"></i> Online training and live onboarding webinars</li>
				</ul>
				<div class="content-img"><img src="image/login-bg-1.png" class="img-fluid"/></div>
			</div>  */}
                    </div>
                </div>
            </div>
  
        </>
    )

}

export default Login;