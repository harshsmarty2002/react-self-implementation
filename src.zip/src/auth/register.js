import React, { useState,useEffect } from 'react';
import axios from 'axios';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { callAPI } from '../Config/apiUtil';
import { apiUrls } from '../Config/apiUrl';
import "../dashboard/components/css/custom.css";
import "../dashboard/components/css/media.css";
import { successMessage } from '../Comman/AlertMassge';
import {Dialog,DialogTitle,DialogContent,DialogActions,Button,Box,IconButton,Typography} from '@material-ui/core';
const Register = () => {
    const navigate = useNavigate()
    const[invoicenoValid,setInvoicenoValid]=useState(null)
    const [isActive, setActive] = useState(false);
    const [deleteBox, setDeleteBox] = useState(false);
    const [notregister, setNoregister] = useState(null)
    const [passwordType, setPasswordType] = useState("password");
	const [errors, setErrors] = useState({})
    const [varifiedOtp,setVarifiedOtp]=useState(null)
    const [formdata, setFormdata] = useState({
     firstname: "",
     lastname: "",
     mobile: "",
    password: "",
    confrimPassword: "",
    status: "",
    referralId: "",
    email: "",
     otp: ""

    })

    let user = JSON.parse(localStorage.getItem('Admin_Data'));
    const [userData, setUserData] = useState(user);
    const logout = ()=>{
         localStorage.removeItem('Admin_Data')
         setUserData()
        
      }

   
    

    const handleChange = (e) => {
        if (e.target.name == "firstname") {
            errors.firstname_error = undefined;
}
if (e.target.name == "lastname") {
    errors.lastname_error = undefined;
}
if (e.target.name == "email") {
    errors.email_error = undefined;
    var pattern = new RegExp(/^(("[\w-\s]+")|([\w-]+(?:\.[\w-]+)*)|("[\w-\s]+")([\w-]+(?:\.[\w-]+)*))(@((?:[\w-]+\.)*\w[\w-]{0,66})\.([a-z]{2,6}(?:\.[a-z]{2})?)$)|(@\[?((25[0-5]\.|2[0-4][0-9]\.|1[0-9]{2}\.|[0-9]{1,2}\.))((25[0-5]|2[0-4][0-9]|1[0-9]{2}|[0-9]{1,2})\.){2}(25[0-5]|2[0-4][0-9]|1[0-9]{2}|[0-9]{1,2})\]?$)/i);
if (pattern.test(e.target.value)) {
    check_email_existornot(e.target.value)
}
else{
    setInvoicenoValid(null)
}
    
}
if (e.target.name == "mobile") {
    if(e.target.value.length==11) return false; 
    errors.mobile_error = undefined;
    setNoregister(null)
}
if (e.target.name == "password") {
    errors.password_error = undefined;
}
if (e.target.name == "otp") {
    if(e.target.value.length==7) return false;
}

        setFormdata((formdata) => ({ ...formdata, [e.target.name]: e.target.value }))
    }

    const check_email_existornot = async (gstVal = '') => {
        try {
            let no = (gstVal != null && gstVal.length > 0) ? gstVal : formdata.email
            let query = {email: no }
            const apiResponse = await callAPI(apiUrls.check_email_existornot, query, "GET");
            if (apiResponse.data.status != null && Object.keys(apiResponse.data.status).length > 0) {
               if(apiResponse.data.status=="User email already exist."){
                setInvoicenoValid("Email already exist")
               
               }
               else {
                setInvoicenoValid(null)
    
            }
    
            }
          
        }
    
        catch (err) {
            console.log(err)
        }
    }

    const togglePassword =()=>{
        if(passwordType==="password")
        {
         setPasswordType("text")
         return;
        }
        setPasswordType("password")
      }
    
    
    const ragisterForm = async (e) => {
        const newData = {
            firstname:formdata.firstname,
            lastname:formdata.lastname,
            mobile:formdata.mobile,
            password:formdata.password,
            confrimPassword:formdata.password,
            status:"",
            referid:userData?.userId ? userData?.userId :"sales@unifiergroup.com",
            email:formdata.email,
            otp:formdata.otp
        }
		if (Validate()) {
            axios.post(process.env.REACT_APP_API + 'AccountPost/MemberRegister', newData, {
                headers: {
                    "Content-Type": "application/json"
                }
            })
                .then(res => {  
                    if (res.data.status == "otp_not_verify") {
                        setVarifiedOtp("OTP is not Valid") 
                    }
                   
                    else{
                        setVarifiedOtp(null)
                        successMessage("Register Successfully")
                        navigate('/login')
                    }
                  
                       
                   
                }).catch(err => {

                console.log(err.errors)
            })
		}
        
    }



    const getotp = async () => {
		try {
			let query = { mobile: formdata.mobile }
			const apiResponse = await callAPI(apiUrls.SendOTP,query, "POST");
            if (apiResponse.data.status == "Mobile number already exist.") {
                setNoregister('Mobile number already register');
                setActive(false)
                setDeleteBox(false)
            }
           
            else{
                setNoregister(null)
                setActive(true)
                setDeleteBox(false)
            }
		//console.log(apiResponse.data.status)
		} catch (err) {
			console.log(err)
		}
	}


    const togalbutton = ()=>{
        if (Validate() && invoicenoValid==null) {
         getotp()
        }
        else{
            setDeleteBox(false)
        }
    }

	function Validate() {

        let error = {};
        let validate = true;
        if (!formdata.firstname) {
            validate = false;
            error["firstname_error"] = "(required)";
        }
        if (!formdata.lastname) {
            validate = false;
            error["lastname_error"] = "(required)";
        }
        var pattern = new RegExp(/^(("[\w-\s]+")|([\w-]+(?:\.[\w-]+)*)|("[\w-\s]+")([\w-]+(?:\.[\w-]+)*))(@((?:[\w-]+\.)*\w[\w-]{0,66})\.([a-z]{2,6}(?:\.[a-z]{2})?)$)|(@\[?((25[0-5]\.|2[0-4][0-9]\.|1[0-9]{2}\.|[0-9]{1,2}\.))((25[0-5]|2[0-4][0-9]|1[0-9]{2}|[0-9]{1,2})\.){2}(25[0-5]|2[0-4][0-9]|1[0-9]{2}|[0-9]{1,2})\]?$)/i);

       if (formdata.email != ""){
      
                     if (!pattern.test(formdata.email)) {
                        validate = false;
                        error["email_error"] = "Enter valid email";
                  
                    }
       } 
  
       
        if (!formdata.mobile) {

            validate = false;
            error["mobile_error"] = "(required)";
        }
        else  if (formdata.mobile.length != 10) {
            validate = false;
            error["mobile_error"] = "Enter 10 digit no";
        }
		if (!formdata.password) {

            validate = false;
            error["password_error"] = "(required)";
        }

        else if (formdata.password.length < 8){
            validate = false;
            error["password_error"] = "min 8 char";
        }
        else if (formdata.password.length > 20){
            validate = false;
            error["password_error"] = "max 20 char";
        }
		
        setErrors(error)
        return validate;

    }
    const blockInvalidChar = e => ['e', 'E', '+', '-','.'].includes(e.key) && e.preventDefault();
    const handleKeyDown = e => {
        if (e.key === " ") {
          e.preventDefault();
        }
      };
 
  //console.log(formdata.email)
  
  
    return (
        <>
            <div class="guest">
<p style={{color:"#fff"}}>Welcome {userData?.username ? userData?.username : "Guest"}</p>
    <button type='Submit' onClick={logout} className='logout_btn'>Logout</button>
  </div>
       
<div class="login">
	<div class="row g-0">
   
		<div class="col-lg-6 position-relative">
			<div class="login-form sign_up">
				<div class="company_logo text-center">
					<img src="/image/unibill-logo-final-sending.png"/>
				</div>
				<div class="login_heading">
					<h2>Sign up</h2>
					<p>Please log in or sign up for an account</p>
				</div>
				<div class="login_input">
                    <div className="row">
                        <div className="col-md-6">
                        <div class="form-group">
						<label><i class="fa fa-user" aria-hidden="true"></i> First name<span className="mendetory_flied"><i className="fa fa-star" aria-hidden="true"></i></span>  {errors.firstname_error && <div className="error_msg">{errors.firstname_error}</div>}</label>
						<input type="text" onChange={handleChange}  name="firstname" value={formdata.firstname} class="form-control" placeholder="Enter First Name"/>
						
					</div>
                        </div>
                        <div className="col-md-6">
                        <div class="form-group">
						<label><i class="fa fa-user" aria-hidden="true"></i> Last name<span className="mendetory_flied"><i className="fa fa-star" aria-hidden="true"></i></span>  {errors.lastname_error && <div className="error_msg">{errors.lastname_error}</div>}</label>
						<input type="text" onChange={handleChange} name="lastname" value={formdata.lastname} class="form-control" placeholder="Enter Last Name"/>
                       
					</div>
                        </div>
                        <div className="col-md-6">
					<div class="form-group">
						<label><i class="fa fa-lock" aria-hidden="true"></i> Password<span className="mendetory_flied"><i className="fa fa-star" aria-hidden="true"></i></span>  {errors.password_error && <div className="error_msg">{errors.password_error}</div>}</label>
						<input type={passwordType} onChange={handleChange}  autoComplete="new-password" name="password" value={formdata.password} class="form-control" placeholder="Enter Password"/>
                        <span className='hide' onClick={togglePassword}>
                                            { passwordType==="password"?   <i class="fa fa-eye-slash" aria-hidden="true"></i>: <i class="fa fa-eye" aria-hidden="true"></i>}
                                            </span>
					
					</div>
                    </div>
                    <div className="col-md-6">
                    <div class="form-group">
						<label><i class="fa fa-envelope" aria-hidden="true"></i> Email {errors.email_error && <div className="error_msg">{errors.email_error}</div>} {invoicenoValid && <div className="error_msg">{invoicenoValid}</div>}</label>
						<input type="text" onKeyDown={handleKeyDown} onChange={handleChange} value={formdata.email}   name="email" class="form-control" placeholder="Enter Email"/>  
					</div>
                    </div>
                    </div>
					<div className='row'>
                    <div className={!isActive?"col-md-12":"col-md-6"}>
					<div class="form-group">
						<label><i class="fa fa-mobile" aria-hidden="true"></i> Mobile no.<span className="mendetory_flied"><i className="fa fa-star" aria-hidden="true"></i></span>  {errors.mobile_error && <div className="error_msg">{errors.mobile_error}</div>}{notregister && <div className="error_msg">{notregister}</div>}</label>
						<div class="d-flex with_otp">
							<div class="custom_input position-relative w-100">
								<input type="number" min="0" onWheel={() => document.activeElement.blur()} onKeyDown={blockInvalidChar} readOnly={isActive ? true : false}  onChange={handleChange} name="mobile" value={formdata.mobile}  class="form-control" placeholder="Enter Mobile Number"/>
								<span class="number_input">+91</span>
							</div>
							
						</div>
					</div>
                    </div>
                    <div className="col-md-6">
					<div class={!isActive ? "form-group for_otp" : "form-group for_otp active"}>
						<label><i class="fa fa-comment" aria-hidden="true"></i> OTP<span className="mendetory_flied"><i className="fa fa-star" aria-hidden="true"></i></span>{varifiedOtp && <div className="error_msg">{varifiedOtp}</div>}</label>
						<input type="number" min="0" onWheel={() => document.activeElement.blur()} onKeyDown={blockInvalidChar} onChange={handleChange} name="otp" value={formdata.otp} class="form-control" placeholder="Enter 6 Digit OTP "/>
                        </div>

					</div>
                    </div>
                   
					<div class="form-group mb-0">
                    {!isActive &&	<button type='submit' onClick={()=>setDeleteBox(true)}   class="btn w-100">Get OTP</button>}
                    {isActive &&  <button type='submit' onClick={ragisterForm} class="btn w-100" >Sign up</button>}
					</div>
				</div>
				<div class="not_register text-center mt-3">
					<p>Already a customer ? <Link to="/login" class="ms-3">Log in</Link></p>
				</div>
			</div>
		</div>
		{/* <!-- login_bg_secound class add on secound condition --> */}
		<div class="col-lg-6 login_bg">
			 <div class="middle_login_img">
				<img src="/image/MicrosoftTeams-image-left.png" class="img-fluid"/>
			</div>
			 {/* <div class="bg_with_content position-relative">
				<h3>Start your free trial. No credit card required, no software to install.</h3>
				<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
				<ul>
					<li><i class="icofont-tick-mark"></i> Preloaded data or upload your own</li>
					<li><i class="icofont-tick-mark"></i> Preconfigured processes, reports, and dashboards</li>
					<li><i class="icofont-tick-mark"></i> Guided experiences for sales reps, leaders, and administrators</li>
					<li><i class="icofont-tick-mark"></i> Online training and live onboarding webinars</li>
				</ul>
				<div class="content-img"><img src="image/login-bg-1.png" class="img-fluid"/></div>
			</div> */}
		</div>
	</div>
</div>
<Dialog open={deleteBox}  maxWidth="sm" width={25}>
					<DialogTitle>Check Number</DialogTitle>
					<Box position="absolute" top={0} right={0}>
						<IconButton onClick={() => setDeleteBox(false)}>
							<i class="fa fa-close" />
						</IconButton>
					</Box>
					<DialogContent>
						<Typography>Please Check<b> {formdata.mobile} </b>Number to get OTP</Typography>
					</DialogContent>
					<DialogActions>
						<Button color="success" variant="contained" onClick={() => setDeleteBox(false)} >
							Change Number
						</Button>
						<Button style={{background:"green",color:"white"}} onClick={togalbutton}   >
							Get OTP
						</Button>
					</DialogActions>
				</Dialog>
      </>  
    )

}

export default Register;