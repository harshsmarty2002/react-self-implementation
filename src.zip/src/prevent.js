// import React from "react";
// import './prevent.css';
const Prevent=()=>
{               
    // const blockInvalidChar = e => ['e', 'E', '+', '-','.'].includes(e.key) && e.preventDefault();
    // const handleKeyDown = e => {
    //     if (e.key === " ") {
    //       e.preventDefault();
    //     }
    //   };
    

     const block = (e) =>['e','E','.','-','+'].includes(e.key) && e.preventDefault();
    
    return(
        <>
        <div className="container">
            <div className="form-group col-lg-6">
                <label>
                    Enter Mobile Number
                </label>    
                <input type="number" min="0" className="form-control" onKeyDown={block}/>
                {/* <span className='hide' onClick={togglePassword}>
                        {passwordType === "password" ? <i className="fa fa-eye-slash" aria-hidden="true"></i> : <i className="fa fa-eye" aria-hidden="true"></i>}
                      </span> */}
                <button className="btn btn-sm btn-primary">Save</button>

                    
            </div>
            <div className="col-lg-6"></div>

        </div>
        
        
        </>
    );

}
export default Prevent;
