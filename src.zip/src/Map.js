import React from "react";

function Map()
{

    const status=document.querySelector(".status");
    const success = (position)=>
    {
        console.group(position);
        status.textContent='Your Location is ';
    } 
    
    const error =()=>
    {
        status.textContent='unable to reach your Location';
    }
    navigator.geolocation.getCurrentPosition(success,error);
    document.querySelector(".btn").addEventListener("click",)
    return(
        <>
        <div className="status">

        </div>
        <button className="btn"></button>


        
        </>
    );
}
export default Map;