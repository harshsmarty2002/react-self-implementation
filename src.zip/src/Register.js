import React from "react";
function Register(){
    return(
        <>
        <h1>
            Inside the register
        </h1>
        
        </>
    );

}
export default Register;