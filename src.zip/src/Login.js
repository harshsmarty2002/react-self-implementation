import React, { useState } from "react";
import IMG from "./image/increase.png";
// import { Link } from "react-router-dom";
// import Register from './Register';
// import chose from "./image/dummy_img_1.jpg";
// import left from './image/background3.jpg';
// import Map from "./Map";
import './Login.css';
function Login()
{
   
    function find()
    {

        const success=(position)=>
        {
            console.log(position);
            var lat=position.coords.latitude;
            var log=position.coords.longitude;
            document.getElementById("latitude").innerHTML="Latitude is="+ ' '+lat;
            document.getElementById("longitude").innerHTML="Longitute is="+ ' ' +log;
            
            // const l=position.coords.latitude;
            // const m=l.toString();
            // setValue1({m});
            // console.log({m});
            // console.log(value1);
            // var val=document.getElementById("latitude");
            // var val2=document.getElementById("logtitude")
            
            // val.innerHTML=l;
            // console.log(val);
            
            // const m=position.coords.longitude;
            //    val.innerHTML=position.coords.latitude;
            // console.log(position.coords.latitude);
            
        
            // console.log(val);
            
   
        }
        const error=()=>
        {
            document.getElementById("logitute").innerHTML="Undefine accur";
            }
            navigator.geolocation.getCurrentPosition(success,error);
    }
    // document.querySelector("#btns").addEventListener("click",find);
       

    let [mobile,setMobile]=useState("");
    let [user,setUser]=useState("");
    let [mails,setmails]=useState({
        selectedmail:" "
    });
    let [pass,setPass]=useState("");
    let [passwordtype,setPasswordType]=useState("password");
    let [radio,setradio]=useState({
        selectedOption:"Mobile"

    });
    function radiobutton(e)
    {
        setradio({
            selectedOption:e.target.value
        })
    }

    function mail_function(e)
    {
        // setmails({
        //     selectedmail:e.target.value
        //    });

           let letter=/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;

           if(mails.selectedmail.match(letter))
           {
                alert("Email is Valid"); 
                return true;
           }

           mails.focus();
               return false;

    }
    // function handlemail(e){

    //     // setmails(e.target);
    //     // console.log(letter);
    //     let mm=document.getElementById("mm");
    //     // console.log(mails);

    //     let letter=/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
    //     
    // if(mails.match(letter))
    //     {
    //             alert("Email is Valid"); 
    //             return true;
    //     }
       
    //   else{
                
    //     alert("Email is not valid");
    //     mm.focus();
    //     return false;
    //   }
    // }

    const toogle=()=>
    {
        // let t2=document.getElementById("chq2");
        // let t3=document.getElementById("chq3");

        // var t1=document.getElementsByName("chq1");
             
        if(passwordtype=="password")
        {
            setPasswordType("text");
            return;
        }
        setPasswordType("password");


            // if(t1.type=="password")
            // {
            //     console.log(t1.type);

            //     t1.type="text";
                
            //     setPasswordType("text");
            //     return;
                
            // }  
            // t1.type="password";
            // setPasswordType("password");


      
       
        // else if(t2.type==="password" ) 
        // {
        //     t2.type="text";
            
        //     setPasswordType("text");
        //     return;

        // }
        // else if(t3.type==="password" ) 
        // {
        //     t3.type="text";
            
        //     setPasswordType("text");
        //     return;

        // }
       
        // t2.type="password";
        // t3.type="password";

    }


    // function pass_word()
    // {
    //     let pass=document.getElementById(".pass");
    //     if(pass.length>6 || pass.length<6)
    //     {
    //         alert("password must be 6 digits");
    //         return false;
    //     }
    //     else{
    //         alert("password save success fully");
    //     }
    // }
    const checkChar=(e)=>{ 
        // let t=document.getElementById("number").value;
        // if(t.length>9)
        // {
        //     e.preventDefault();
        // }      
        ['e','E','.','+','-'].includes(e.key) && e.preventDefault();     
    }
    // Example starter JavaScript for disabling form submissions if there are invalid fields
// (function () {
//     'use strict'
  
//     // Fetch all the forms we want to apply custom Bootstrap validation styles to
//     var forms = document.querySelectorAll('.needs-validation'); 
    
//     // console.log(forms);
  
//     // Loop over them and prevent submission
//     Array.prototype.slice.call(forms)
//       .forEach(function (form) {
//         form.addEventListener('submit', function (event) {
//                     if (!form.checkValidity()) {
//                         event.preventDefault()
//                         event.stopPropagation()
//                     }
                    
                    
            
//                     form.classList.add('was-validated')
//                     }, false)
//                                 })                    
//   })()
    // const checkNum=(e)=>['0','1','2','3','4','5','6','7','8','9'].includes(e.key) && e.preventDefault();
    return(
        
        <div>
           <div className="row ">
           <div className="col-lg-6 form-group" id="left" >
               <div className="login_form">
                <div className="login_heading">
                    <div className="login-logo">
                    <img src={IMG}/>

                    </div>
                    <div className="login_text">
                        <h4><strong>HRMS Portal </strong></h4>
                        <p>Login In Here</p>
                    </div>

                </div>
                <div className="login_input">

                <div className="login_input_items">
                <input type="radio" name="Mobile" id="Mobile" checked={radio.selectedOption==="Mobile"?true:false} onChange={radiobutton} value="Mobile"/>
                 <label htmlFor="Mobile">With Mobile</label >

                 <input type="radio"  name="User" id="User" checked={radio.selectedOption==="User"?true:false} onChange={radiobutton} value="User" />
                 <label htmlFor="User">With User</label>

                 <input type="radio"  name="Email" id="Email" checked={radio.selectedOption==="Email"?true:false} onChange={radiobutton} value="Email"/>
                 <label htmlFor="Email">With Email</label>
                
                </div>
                
                    <form className="needs-validation" noValidate>
                        <>
                        {radio.selectedOption==="Mobile"?
                        <div className="form-group">
                              
                            <label className="form-label" htmlFor="validationCustom03"><i className="bi bi-phone-fill"></i>Mobile</label>
                            
                            <div className="form-group has-validation">
                        
                            <div className="input-group prepend">
                                <span className="input-group-text" id="validationCustom03">+91</span>
                                <input type="number" className="form-control" id="number" aria-describedby="basic-addon1"  placeholder="Enter Mobile Number"  value={mobile} onChange={(e)=>setMobile(e.target.value)} onKeyDown={checkChar} required/>
                                <div className="invalid-feedback">

                                this field is required
                                    
                                </div>
                            </div>
                            
                            {/* <div id="nine" className="input-group-prepend">+91</div> */}
                           
                            </div>
                             

                        <label><i className="bi bi-lock-fill"></i>Password</label>
                           <div className="input-group">
                           <input type={passwordtype} className="form-control" name="chq1" onChange={(e)=>setPass(e.target.value)} value={pass} placeholder="Enter Your Password"  required/>
                            <span className="input-group-text" onClick={toogle}>{passwordtype==="password"?<i class="bi bi-eye-slash-fill" aria-hidden="true" ></i> :<i class="bi bi-eye-fill" aria-hidden="true"></i> }</span>
                        <div className="invalid-feedback">
                            invalid password
                        </div>
                       
 
                            </div> 


                        </div>
                        :
                        radio.selectedOption==="User"?
                        <div className="form-group">
                            <label className="form-label"><i className="bi bi-person-fill"></i>Username</label>
                            <div className="form-group has-validation">
                                <div className="input-group">
                                <span className="input-group-text"><i className="bi bi-person-fill"></i></span>
                            <input type="text" className="form-control" placeholder="Enter username" value={user} onChange={(e)=>setUser(e.target.value)} required/>
                            <div className="invalid-feedback">
                                invalid user

                            </div>

                                </div>
                            <label><i className="bi bi-lock-fill"></i>Password</label>
                           <div className="input-group">
                             <input type={passwordtype} className="form-control" name="chq1" onChange={(e)=>setPass(e.target.value)} value={pass} placeholder="Enter your Password Here" required/>

                            <span className="input-group-text"  onClick={toogle} >{passwordtype==="password"?<i className="bi bi-eye-slash-fill" aria-hidden="true" ></i> :<i className="bi bi-eye-fill" aria-hidden="true"></i> }</span>
                  
                            <div className="invalid-feedback">
                                invalid password

                            </div>

                           </div>


                            </div>
 
                        </div>
                        :
                        <div className="form-group">
                            <label className="form-label"><i className="bi bi-envelope-fill"></i>Email</label>
                            <div className="form-group has-validation">
                               <div className="input-group"> 
                              
                            <input type="email" className="form-control" id="emailId" onChange={mail_function=(e)=>setmails(e.target.value)} placeholder="Enter Email"  required/>
                            <span className="input-group-text">@gmail.com</span>
                                <div className="invalid-feedback">
                                    invalid Email
                                </div>
                               </div>
                            
                            <label className="from-label"><i className="bi bi-lock-fill"></i>Password</label>
                           <div className="input-group">
                           <input type={passwordtype} className="form-control" name="chq1" onChange={(e)=>setPass(e.target.value)} value={pass} placeholder="Enter your Password Here" required/>
                           <span className="input-group-text"  onClick={toogle} >{passwordtype==="password"?<i class="bi bi-eye-slash-fill" aria-hidden="true" ></i> :<i class="bi bi-eye-fill" aria-hidden="true"></i> }</span>
                  
                          
                            <div className="invalid-feedback">
                                    invalid password
                                </div>
                            </div>
                           </div>

                        </div>
                        
                     
                    }
                    {/* <input className="btn w-100 btn-primary" id="btn" type="button" onClick={mail} value="submit"/> */}
                    <button className="btn w-100 btn-primary" id="btn" type="submit" onClick={mails}>submit</button>
 
                        </>

                    </form>
                
             </div>
             <label>don't have any account
                   
             </label><a>register ?</a>
                
                </div> 
             
            </div>
            <div className="col-lg-6 mb-6 left_image" id="right">
               {/* <iframe src= width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe> */}
                <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3490.95030648755!2d77.72476151441543!3d28.95919837597306!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x390c655d213a2899%3A0xf4e21e9587876a73!2sUnifier%20Group!5e0!3m2!1sen!2sin!4v1656323600295!5m2!1sen!2sin" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
             
               
            </div>          
          
            {/* <Map /> */}
            

           </div>
           <button className="btn w-40 btn-primary" onClick={find} >Click Me For Finding Latitude and Longitute</button>

          
            <p id="latitude"></p><p id="longitude"></p>
           <br/>
         
           <div className="input-group">
      <span className="input-group-text" id="inputGroupPrepend">@</span>
      <input type="text" className="form-control" id="validationCustomUsername" aria-describedby="inputGroupPrepend" required/>
  
    </div>
         
           
           

        </div>

      
    );
}
export default Login;