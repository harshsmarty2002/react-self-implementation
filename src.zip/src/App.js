// import { Link } from 'react-router-dom';
import first from './image/login-bg.png';
import second from './image/unibill-logo-removebg.png';

import { useState } from 'react';
import './custom.css';

// import Prevent from './prevent';

function App() {
  const [radio, setRadio] = useState({
    selectedOption: "Mobile"
  });

  const radiobutton = (e) => {
    setRadio({
      selectedOption: e.target.value,
    });
  }


  
  const handleChange = () => {
    console.log("Inside Handle Key Down");
  }
  const errors = () => {
    console.log("Inside Handle Key Down");
  }
  const isloader = () => {
    console.log("Inside Handle Key Down");
  }
  const LoginForm = () => {
    console.log("Inside Handle Key Down");
  }
  const togglePassword = () => {
    console.log("Inside Handle Key Down");
  }
  const notregister = () => {
    console.log("Inside Handle Key Down");

  }
  const formdata = () => {
    console.log("inside formdata");
  }
  const passwordType = () => {

    console.log("inside formdata");
  }

  //***********For Invalid Chaacters********* */
  const blockInvalidChar = e => ['e', 'E', '+', '-', '.'].includes(e.key) && e.preventDefault();

  const handleKeyDown = e => {
    if (e.key === " ") {
      e.preventDefault(); 
    }
  };



  return (
    <>
    
    {/* <Prevent /> */}

      <div className="login">
        <div className="row g-0">

          <div className="col-lg-6 position-relative">

            <div className="login-form">

              <div className="company_logo text-center">

                <img src={second} />
              </div>
              <div className="login_heading">
                <h2>Log in</h2>
                <p>Please log in or sign up for an account</p>
              </div>

              <div className="login_input">
                <div>
                  <div className="form-check form-check-inline">

                    <input className="form-check-input" type="radio" checked={radio.selectedOption === "Mobile" ? true : false} name="Mobile" id="Mobile" onChange={radiobutton} value="Mobile" />
                    <label className="form-check-label" for="Mobile">Mobile No</label>
                  </div>
                  <div className="form-check form-check-inline">
                    <input className="form-check-input" type="radio" checked={radio.selectedOption === "UserID" ? true : false} onChange={radiobutton} name="User" id="User" value="User" />
                    <label className="form-check-label" for="User">User Name</label>
                  </div>
                  <div className="form-check form-check-inline">
                    <input className="form-check-input" type="radio" checked={radio.selectedOption === "EmailId" ? true : false} onChange={radiobutton} name="Email" id="Email" value="Email" />
                    <label className="form-check-label" for="Email">Email id</label>
                  </div>
                </div>
                <form method="post" onSubmit={LoginForm}>
                  <>
                    {radio.selectedOption === "Mobile" ?
                      <div className="form-group">
                        <label><i className="icofont-smart-phone"></i> Mobile no.</label>
                        <div className="custom_input position-relative">
                          <input type="number" min="0" onKeyDown={blockInvalidChar} value={formdata.amit} onWheel={() => document.activeElement.blur()} className="form-control" name="amit" onChange={handleChange} placeholder="Enter Mobile Number" />
                          <span className="number_input">+91</span>
                        </div>
                        {errors.mobile_error && <div className="error_msg">{errors.mobile_error}</div>}
                      </div>
                      :
                      <div className="form-group">
                        <label><i className="icofont-ui-user"></i> User name.</label>
                        <div className="custom_input position-relative">
                          <input type="text" onKeyDown={handleKeyDown} className="form-control" name="amit" onChange={handleChange} placeholder="Enter User Name" />
                          <span className="number_input"><i className="icofont-ui-user"></i></span>
                        </div>
                        {errors.User_error && <div className="error_msg">{errors.User_error}</div>}
                      </div>
                    }
                    <div className="form-group">
                      <label><i className="icofont-lock"></i> Password</label>
                      <input type={passwordType} value={formdata.india} className="form-control" name="india" onChange={handleChange} placeholder="Enter Password" />


                      <span classNameName='hide' onClick={togglePassword}>
                        {passwordType === "password" ? <i className="fa fa-eye-slash" aria-hidden="true"></i> : <i className="fa fa-eye" aria-hidden="true"></i>}
                      </span>

                      {radio.selectedOption === "Mobile" ?
                        errors.password_error && <div className="error_msg">{errors.password_error}</div> :
                        errors.user_password_error && <div className="error_msg">{errors.user_password_error}</div>
                      }
                    </div>
                    <div className="form-group">
                      <button type='submit' className="btn w-100">{isloader ? '...Please Wait' : 'Log in'}</button>
                      {notregister && <div className="error_msg">{notregister}</div>}
                    </div>
                  </>
                </form>
                {/* <div className="form-group d-flex justify-content-between forgot_password mb-0">
                  <div className="form-check">
                    <input type="checkbox" className="form-check-input" id="exampleCheck1" />
                    <label className="form-check-label" for="exampleCheck1">Remember me</label>
                  </div>
                  <Link to="/Forgot_password">Forgot password ?</Link>
                </div> */}
              </div>
              {/* <div className="not_register text-center mt-3">
                <p>Not registered ? <Link to="/register" className="ms-3">Sign up</Link></p>
              </div> */}
            </div>
          </div>

          <div className="col-lg-6 login_bg">
            {/* {isloader &&
              <div style={{ position: "fixed", top: "0", left: "0", right: "0", background: "rgb(254 253 253 / 85%)", height: "100%", zIndex: "9999" }}>
                <img src="image/loader-gif.gif" className="position-absolute top-50 start-50 translate-middle" style={{ maxHeight: "150px", transform: "translate(-50%, -50%)" }} alt="loading..." /></div>
            } */}
            {/* {isloader && 
                    <img src="image/unifier-logo-gif.gif" className="position-absolute top-50 start-50 translate-middle" style={{maxHeight: "150px"}} alt="loading..." />}   */}
            <div className="middle_login_img">

              <img src={first} className="img-fluid" />

            </div>

            {/* <div className="bg_with_content position-relative">
				<h3>Start your free trial. No credit card required, no software to install.</h3>
				<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
				<ul>
					<li><i className="icofont-tick-mark"></i> Preloaded data or upload your own</li>
					<li><i className="icofont-tick-mark"></i> Preconfigured processes, reports, and dashboards</li>
					<li><i className="icofont-tick-mark"></i> Guided experiences for sales reps, leaders, and administrators</li>
					<li><i className="icofont-tick-mark"></i> Online training and live onboarding webinars</li>
				</ul>
				<div className="content-img"><img src="image/login-bg-1.png" className="img-fluid"/></div>
			</div>  */}
          </div>
        </div>
      </div>

    </>
  );
}

export default App;
