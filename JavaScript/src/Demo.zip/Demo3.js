import React, { useEffect } from "react";
import { useState } from "react";
import { API, callAPI } from '../../Config/apiUtil';
import { apiUrls } from '../../Config/apiUrl';
import Autocomplete from 'react-autocomplete';
import "./demo2.css";
import Cookies from "js-cookie";
import { v4 as uuid } from 'uuid';
import moment, {Moment} from "moment";
import Number_to_word_convoter from '../../Number_to_Word/number_to_word';
import { useMemo } from "react";

function Demo3() {

  const [productvalue,setProductvalue]=useState("");
  const [productdetail,setProductdetail]=useState({});
  const [allproductdetails,setAllproductdetails]=useState({});
  const [modaldata,setModaldata]=useState({});
  const [radiobuttons,setRadiobuttons]=useState({
    itemtype:"1"
  });
  const [Itemsname,setItemsname]=useState([]);
  const [unit,setUnit]=useState([]);
  const [itemwise,setItemwise]=useState([]);
  const [gstdisplay,setGstdisplay]=useState([]);
  const [item,setItem]=useState({

    gst:"",
    hsn:"",
    name:"",
    unit:"",
    stock:"",
    summary:"",
    brand:"",
    productcode:"",
    size:"",
    color:"",

  });
  const unitapi=async()=>{
    try{
      const apiResponse = await callAPI(apiUrls.get_all_units, {}, "GET");
      
      setUnit(apiResponse.data.value);
      
    }
    catch(error){
      console.log(error);

    }
    
  }
  
  const handlekeysfun=(e)=>{

    if(e.target.name=="name")
    {
      let special = /^[A-Za-z0-9-_]+$/i;
      if(e.key.match(special))
      {
        return true;
      }
      e.preventDefault();
    }
    if(e.target.name=="hsn")
    {
      let special = /^[0-9]+$/i;
      if(e.key.match(special))
      {
        return true;  
      }
      e.preventDefault();

    }
    if(e.target.name=="summary")
    {
      let special = /^[A-Za-z0-9-_]+$/i;
      if(e.key.match(special))
      {
        return true;
      }
      e.preventDefault();
    }
    if(e.target.name=="color")
    {
      let special = /^[A-Za-z]+$/i;
      if(e.key.match(special))
      {
        return true;
      }
      e.preventDefault();

    }
  }
  const handledrop=()=>{
    console.log()
  }
  const handlegst=(e)=>{

    setItem({...item,[e.target.name]:e.target.value});
  }
   const bid=Cookies.get('bid');
   const [state,setState]=useState([]);
   let [city,setCity]=useState([]);
   const [date,setdate]=useState(moment(new Date()).format("YYYY-MM-DD"));
   let [due,setDue]=useState(moment(new Date()).format("YYYY-MM-DD"));
   let [partyvalue,setPartyvalue]=useState("");
   let [companyname,setCompanyname]=useState("");
   let [gstval,setGstval]=useState("");
     const unique_id = uuid();
   const small_id = unique_id.slice(0,4);
   let [addmore,setAddmore]=useState([
    {
    id:"",
    charges:"",
    gst:"",
    amount:"",
    gstamt:"",
    netamt:"",    
   }]);
  
   let [check,setCheck]=useState(false);
   let [checkvalue,setCheckvalue]=useState("not_new_customer");
   let [additional,setAdditional]=useState(false);
   let [partyname,setPartyName]=useState({})
   let [alldata,setAlldata]=useState({});

   const cancelmodal=()=>{
    setItem({ 
    gst:"",
    hsn:"",
    name:"",
    unit:"",
    stock:"",
    summary:"",
    brand:"",
    productcode:"",
    size:"",
    color:"",
    });

    // console.log("called successfully");

  }

  //  const alls=alldata[0];
  //  console.log(alls.state);

   let [invoice,setInvoice]=useState({  
    gstno:null,  
    challanvalue:null,
    challantext:null,
    tradename:"",
    state:"",
    address:"",
    country:"",
    city:"",
   })

   const handleinvoice=(e)=>{
  if(e.target.name=="Challan");
  {
    if(e.target.value=="")
    {
        invoice.challanvalue=null;
    }
  }
  if(e.target.name=="Invoiceno")
  {
    if(e.target.value=="")
    {
        invoice.challanvalue=null;
    }
  }
  if(e.target.name=="Orderno")
  {
    if(e.target.value=="")
    {
        invoice.challanvalue=null;
    }
  }
  setInvoice({...invoice,[e.target.name]:e.target.value});
   }
   
   const handleCheckbox=(e)=>
   {
    let isChecked= e.target.checked;
    if(isChecked)
    {
      console.log("once");
        setCheck(true);
        setCheckvalue("new_customer");
        setPartyvalue("");
        setCompanyname("");
        setGstval("");
          setAlldata({
            ["state"]:"",
            ["city"]:"",
            ["address"]:"",
            ["pincode"]:"",
            ["partyname"]:"",
          });
    }
    else{
        setCheck(false);
        setCheckvalue("not_new_customer");
        setPartyvalue("");
        setCompanyname("");
        setGstval("");
          setAlldata({
            ["state"]:"",
            ["city"]:"",
            ["address"]:"",
            ["pincode"]:"",
            ["partyname"]:"",
          });
    }
   }

   const displayall=async()=>{
    let query={ bid: bid }
    const apiResponse = await callAPI(apiUrls.get_all_customerpartyname, query, "GET");
    if(Object.keys(apiResponse.data.value).length>0)
    {
      setPartyName(apiResponse.data.value);
    }
    
    // try
    // {
    //   if(apiResponse.data.value!=null && apiResponse.data.value!=undefined)
    //   setPartyName("");
    // }
    // catch(error){
    //   console.log(error);
    // }
   }

   useEffect(()=>{displayall();},[]);
  //  useEffect(()=>{gstapi();},[alldata.gstno || alldata.companyname || partyname.companyname])
    const gstapi=async(gstval='')=>{
      console.log(gstval);

    let query={gstno:gstval?gstval:null};
    const apiResponse = await callAPI(apiUrls.check_company_gstno_existornot, query, "GET");   
    console.log(apiResponse.data.value);
    if(Object.keys(apiResponse.data.value)!=undefined && Object.keys(apiResponse.data.value)!=null) 
    {
      setAlldata({
        
        // apiResponse.data.value.data.pradr.addr.stcd!=null?apiResponse.data.value.data.pradr.addr.stcd:,
        ["city"]:apiResponse.data.value.data.pradr.addr.dst!=null?apiResponse.data.value.data.pradr.addr.dst:apiResponse.data.value.data.pradr.addr.loc,
        ["address"]:`${apiResponse.data.value.data.pradr.addr.bno},${apiResponse.data.value.data.pradr.addr.bnm},${apiResponse.data.value.data.pradr.addr.flno},${apiResponse.data.value.data.pradr.addr.st}`,
        ["state"]:apiResponse.data.value.data.pradr.addr.stcd,
        ["pincode"]:apiResponse.data.value.data.pradr.addr.pncd,
        ["partyname"]:apiResponse.data.value.data.lgnm,
      });
    } 
    if(Object.keys(apiResponse.data.value)==undefined )
      {
        setAlldata({
        ["state"]:"",
        ["city"]:"",
        ["address"]:"",
        ["pincode"]:"",
        ["partyname"]:"",
      });
      }
    
    // setInvoice({
    //   tradename:apiResponse.data.value.data.tradeNam!=undefined?apiResponse.data.value.data.tradeNam:null,
    //   // state:apiResponse.data.value.data.pradr.addr.stcd,
    //   // city:apiResponse.data.value.data.pradr.addr.loc,
    //   // address:`${apiResponse.data.value.data.addr.bnm!=undefined?apiResponse.data.value.data.addr.bnm:null},${apiResponse.data.value.data.addr.flno!=undefined?apiResponse.data.value.data.addr.flno:null},${apiResponse.data.value.data.addr.loc!=undefined?apiResponse.data.value.data.addr.loc:null}`,
    //  });

   }

   const handlekeys=(e)=>{
    let special = /^[A-Za-z0-9]+$/i;
    if(e.key.match(special))
    {
      return true;
    }
    e.preventDefault();
    return false;
   }
   
   const handlechange=(e)=>{
    let r=e.target.value.trim().toUpperCase(); 
    
    if(e.target.name=="gstno")
    {
        if(r.length==15)
        {
            gstapi(r);
        }
        if(r.length<15)
        {
            setInvoice({
                tradename:""
            })
        }
        if(e.target.value=="")
        {

          // alldata.state="";

          setAlldata({
            ["gstno"]:"",
            ["state"]:"",
            ["city"]:"",
            ["address"]:"",
            ["pincode"]:"",
            ["partyname"]:"",
          });
        }
        if(e.target.value=="urp" || e.target.value=="URP")
        {
          setAlldata({
            ["gstno"]:e.target.value,
          });

          // gstapi(e.target.value);
        }
    }   
    setAlldata(((val)=>({...val,[e.target.name]:e.target.value})));
   }
   
//    const array = [
//     {bpid: 1134, bid: '0912211950b01', partyName: 'THE KARNATAKA BANK LIMITED', companyname: 'THE KARNATAKA BANK LIMITED', gstin: '37AABCT5589K2ZN'},
//     {bpid: 2129, bid: '0912211950b01', partyName: 'DELHI METRO RAIL CORPORATION LIMITED', companyname: 'Atoz', gstin: '06AAACD3254A1DM'},
//     {bpid: 2134, bid: '0912211950b01', partyName: 'V MART RETAIL LIMITED', companyname: 'V MART RETAIL LTD', gstin: '06AABCV7206K1Z9'},
//     {bpid: 2135, bid: '0912211950b01', partyName: 'OSGAN CONSULTANTS PVT LTD', companyname: 'OSGAN CONSULTANTS PVT.LTD', gstin: '07AAACO4986A1ZJ'},
//     {bpid: 2152, bid: '0912211950b01', partyName: 'UJJIVAN SMALL FINANCE BANK LIMITED', companyname: 'UJJIVAN SMALL FINANCE BANK LIMITED', gstin: '18AABCU9603R1ZM'},
//     {bpid: 2220, bid: '0912211950b01', partyName: 'UJJIVAN SMALL FINANCE BANK LIMITED', companyname: 'UJJIVAN SMALL FINANCE BANK LIMITED', gstin: '22AABCU9603R1ZX'},
//     {bpid: 2520, bid: '0912211950b01', partyName: 'dfdsf', companyname: 'skjdsaf', gstin: 'URP'},
// ];
   
   const clickevent=()=>{
    
    if(additional==false)
    {
      setAdditional(true);
    }
    if(additional==true)
    {

      setAdditional(false);
    }
   
   }

   const cancelfunc=(val)=>{

    let set=addmore.filter((element)=>{return element.id!=val.id})
    setAddmore(set);
   
   }
  //  let ru=alldata.map((e)=>(e.state));
  //  console.log(ru);
  //  console.log(alldata.state)
const handlechangeaddmore=(e,id)=>
{

  let filtr=addmore.filter((e)=>{
    if(e.id==id)
    {
      return e;
    }
  })
  let filtrlength=filtr[0];
  let updatedaddmore={
    ...filtrlength,[e.target.name]:e.target.value
  };
  let indxnumber=addmore.findIndex((e)=>{return e.id==id});
  addmore[indxnumber]=updatedaddmore;
  setAddmore([...addmore]);
}
   const addmorefunc=()=>{
    const updatedarray=[...addmore,{
      id:small_id,
    charges:"",
    gst:"",
    amount:"",
    gstamt:"",
    netamt:"", 
    }];
    setAddmore(updatedarray);
   }
useEffect(()=>{sums();},[addmore]);
  
const [totals,setTotals]=useState("");
   const sums=()=>{
    // let su=addmore.amount;
    let sums=addmore.reduce((current,value)=>current+Number(value.amount),0);
    setTotals(sums);
   }
   
   const word=Number_to_word_convoter (Math.round(totals));

   const blocking=(e)=>["-","e","E",","].includes(e.key) && e.preventDefault();
    
   const displaybranch=async(bpid)=>{
    let query = { bpid: bpid?.bpid, bid: bid }
    const apiResponse = await callAPI(apiUrls.get_branch_parties, query, "GET");
    // console.log( apiResponse.data.value);
    if(apiResponse.data.value!=undefined && apiResponse.data.value!=null)
    {
      setAlldata({
        ["state"]:apiResponse.data.value.shippingstate,
        ["city"]:apiResponse.data.value.shippingcity,
        ["address"]:apiResponse.data.value.shippingaddress1,
        ["pincode"]:apiResponse.data.value.shippingpincode,
        ["partyname"]:apiResponse.data.value.partyname,
      });

    }
    setAlldata({
      ["state"]:"",
      ["city"]:"",
      ["address"]:"",
      ["pincode"]:"",
      ["partyname"]:"",
    });
   }

   const displaystate=async()=>{
   try{
    const apiResponse = await callAPI(apiUrls.get_all_state, {}, "GET");
    if(apiResponse.data.value.length>0 && apiResponse.data.value!=undefined && apiResponse.data.value!=null)
    {
      setState(apiResponse.data.value);
    }
    setState();
    
   }
   catch(error){
    console.log(error);
   }
   } 
   useEffect(()=>{displaystate();},[]);

   const selectedState=(e)=>{
    displaycity(e.target.value);
   }

   const displaycity=async(id)=>{
      try {
          let query = { stateId: id }
          const apiResponse = await callAPI(apiUrls.get_all_city, query, "GET");
          setCity(apiResponse.data.value);
   }
   catch(error){
    console.log(error);
   }
  }

  const displayitems=async()=>{
    let query = { bid: bid,itemtype:radiobuttons.itemtype}
    const apiResponse = await callAPI(apiUrls.get_all_item_name, query, "GET");
    
      setItemsname(apiResponse.data.value);
  }

  useEffect(()=>{displayitems();},[radiobuttons]);

  const displayitem=async(prodid)=>{
    let query = { prodid:prodid, bid: bid }
    const apiResponse = await callAPI(apiUrls.GetAllProduct, query, "GET");
    
    // console.log(apiResponse.data.value);

    if (Object.keys(apiResponse.data).length > 0) {
                
      if (apiResponse.data.value != null) {
          // console.log(apiResponse.data.value)
          setAllproductdetails({ ...apiResponse.data.value, ['prodid']: prodid })
          setAllproductdetails({ ...apiResponse.data.value, ['qty']: "1", ['discount']: "0" })
      }
  }
  }
  useEffect(()=>{displayitem(productdetail.prodid);},[productdetail]);

  return (
    <>
      <div className="dashboard_body_content add_item_bg">
        <div className="dashboard_container">
          <div className="row row_div">
            <div className="col-lg-2">
                <select className="form-select">
                    <option>text Invoice</option>
                    <option>Bill Supply</option>
                </select>
            </div>
            <div className="col-lg-6"  style={{display:"flex",justifyContent:"right"}}>
              <input type="checkbox" onChange={(e)=> handleCheckbox(e)} checked={check} />
              <label style={{marginTop:"7px"}}>New Customer</label>
            </div>

            <div className="col-lg-4" style={{display:"flex",justifyContent:"space-around"}}>
                <button className="btn btn-success">Preview</button>
                <button className="btn btn-primary">Save</button>
                <button className="btn btn-danger">Cancel</button>
            </div>

            {checkvalue=="not_new_customer"?
                <div className="col-lg-8" >
                <div className="row row_div labels_size" style={{border:"none"}}>
                 <div className="row">
                 <label>Gst No</label>
                 <div className="form-group search_custom">
                 <Autocomplete 
              items={partyname}
              getItemValue={(item) => item.companyname}
              renderItem={(item, isHighlighted) => (
                <div className="search-list-inner" style={{
               background: isHighlighted ?
                   '#bcf5bc' : 'white',
               zIndex:99,
           }}  key={item.bpid} >
               {item.gstin}
             </div>
           )}

           value={gstval}
           onChange={(e)=>{
            setGstval(e.target.value)
               
            
            if(e.target.value=="")
              {
                setGstval("");
                setPartyvalue(""); 
                setCompanyname("");
                setAlldata({

                  ["state"]:"",
                  ["city"]:"",
                  ["address"]:"",
                  ["pincode"]:"",
                  ["partyname"]:"",

                });
              }
              gstapi(e.target.value);   
           }}

           onSelect={(val,allItems) =>{

            gstapi(allItems.gstin);
            setPartyvalue(allItems.partyName);
            setCompanyname(allItems.companyname);
            displaybranch(allItems.bpid);
            setGstval(allItems.gstin);  
            
            
           }}

           inputProps={{
             className: "form-control",
             placeholder: 'Search Party with GST Number',
             maxLength:"15",
             
         }}
         />
                 </div>
                 </div>
                 <div className="col-lg-6">
                 <label>Company Name</label>
                <div className="form-group search_custom">
                <Autocomplete 
              items={partyname}
              getItemValue={(item) => item.companyname}
              renderItem={(item, isHighlighted) => (
                <div className="search-list-inner" style={{
               background: isHighlighted ?
                   '#bcf5bc' : 'white',
               zIndex:99,
           }}  
           key={item.bpid} >
            {item.companyname}
             </div>
           )}
           value={companyname}
           onChange={(e)=>{
           
              setCompanyname(e.target.value)
              if(e.target.value=="")
              {
                setGstval("");
                setPartyvalue(""); 
                setCompanyname("");
               
                setAlldata({
                  ["state"]:"",
                  ["city"]:"",  
                  ["address"]:"",
                  ["pincode"]:"",
                  ["partyname"]:"",

                });
              }
          }}

            onSelect={(val,allItems) =>{
              
            setPartyvalue(allItems.partyName);
            setCompanyname(allItems.companyname);
            setGstval(allItems.gstin);
            displaybranch(allItems.bpid); 

           }}
           
           inputProps={{
             className: "form-control",
             placeholder: 'Search Party with Company Name ',
             maxLength:"15",
             
         }}
         />
                  </div>
                 </div>
                 <div className="col-lg-6">
                 <label>Party Name</label>
                    <input type="text" value={partyvalue} disabled className="form-control"/>
                 </div>
                 <div className="col-lg-6">
                 <label>State</label>
                    <input type="text" value={alldata.state} disabled className="form-control"/>
                 </div>
                 <div className="col-lg-6">  
                 <label>City</label>
                 <input type="text" disabled value={alldata.city} className="form-control"/>
                 </div>
                 <div className="col-lg-6">
                 <label>Address</label>
                    <textarea value={alldata.address} disabled className="form-control"/>
                 </div>
                 <div className="col-lg-6">
                 <label>Country</label>
                    <input type="text" className="form-control"/>
                 </div>
                 <div className="col-lg-6">
                 <label>Billing Contact No</label>
                    <input type="text" className="form-control"/>
                 </div>
                 <div className="col-lg-6">
                 <label>Billing Pin Code</label>
                    <input type="text" value={alldata.pincode} disabled className="form-control"/>
                 </div>
                </div>
            </div>  
         :
         <div className="col-lg-8" >
             <div className="row row_div labels_size" style={{border:"none"}}>
              <div>
              <label>Company Name</label>
                 <input type="text" onChange={handlechange} value={alldata.partyname} name="partyname" className="form-control"/>
              </div>
              <div className="col-lg-6">
              <label>Party Name</label>
                 <input type="text" disabled value={alldata.partyname}  className="form-control"/>
              </div>
              <div className="col-lg-6">
              <label>Search by GST no</label>
                 <input type="text" onChange={handlechange} onKeyPress={handlekeys} maxLength={15} name="gstno" value={alldata.gstno} className="form-control"/>
              </div>
              <div className="col-lg-6">
              <label>State</label>
              {alldata.gstno=="URP" || alldata.gstno=="urp" ?
              <select  className="form-control" onChange={(e)=>selectedState(e)}>
              <option>Select </option>
              {
              state!=undefined && state.length>0 && state.map((r,ind)=>
                <option key={ind} value={r.stateId}>{r.stateName}</option>
              )
            }
            </select>
            :

            <input type="text" value={alldata.state} name="state" disabled className="form-control"/>
            }
              
              </div>
              <div className="col-lg-6">
              <label>City</label>
              {alldata.gstno=="URP" || alldata.gstno=="urp"?
              <select className="form-control">
              <option>select City</option>
              {city!=undefined && city.length>0 && city.map((r,ind)=>
              <option key={ind} value={r.cityName}>{r.cityName}</option>
              )}
            </select>
            :
            <input type="text" disabled value={alldata.city} className="form-control"/> 
            }
              </div>
              {alldata.gstno=="URP" || alldata.gstno=="urp"
            ?
            <div className="col-lg-6">
              <label>Aadhar Number or Pan Card Number</label>
              <input type="text" onChange={handlechange} className="form-control" placeholder="enter Pan card Number and aadhar card number here"/>
            </div>
            :""
          }
              <div className="col-lg-6">
              <label>Address</label>
              {alldata.gstno=="urp" || alldata.gstno=="URP"?
              <textarea onChange={handlechange} rows={1} name="address" className="form-control"/>
              :
              <textarea value={alldata.address}  onChange={handlechange} name="address" disabled className="form-control"/>
              }

              </div>
              <div className="col-lg-6">
              <label>Country</label>
                 <input type="text" disabled className="form-control"/>
              </div>
              <div className="col-lg-6">
              <label>Billing Contact No</label>
                 <input type="text" disabled className="form-control"/>
              </div>
              <div className="col-lg-6">
              <label>Billing Pin Code</label>
              {alldata.gstno=="URP" || alldata.gstno=="urp"?
                <input type="text" name="pincode" onChange={handlechange} className="form-control"/>
                :
                <input type="text" value={alldata.pincode}  disabled name="pincode" className="form-control"/>
              }
              </div>
     
             </div>
         </div>
        }
            <div className="col-lg-4" >
                <div className="row row_div labels_size">
                    <div>
                        <label>Invoice No</label>
                        <input type="number" className="form-control"/>
                    </div>
                    <div>
                        <label>Invoice Date</label>
                        <input type="Date" max={moment(new Date()).format("YYYY-MM-DD")} onKeyPress={(e)=>e.preventDefault()} required onChange={(e)=>setdate(e.target.value)} value={date} className="form-control"/>
                    </div>
                    <div>
                        <label>Due Date</label>
                        <input type="date" min={moment(new Date()).format("YYYY-MM-DD")} onKeyPress={(e)=>e.preventDefault()} required onChange={(e)=>setDue(e.target.value)} value={due} className="form-control"/>
                    </div>
                    <div>
                        <label>Remarks</label>
                        <textarea rows={1} className="form-control"/>
                    </div>
                    <div>
                        <label >Delivery challan no||invoice no||Order no</label>
                        <select className="form-select"  name="challantext" onChange={handleinvoice} >
                            <option value="">Select any</option>
                            <option value="Challan" selected={invoice.challantext?"true":"false"}>Delivery Challan no</option>
                            <option value="Invoiceno" selected={invoice.challantext?"true":"false"}>Invoice no</option>
                            <option value="Orderno" selected={invoice.challantext?"true":"false"}>Order no</option>
                        </select>
                        {invoice.challantext && 
                        <div className="form-group">
                            <label>{invoice.challantext}</label>
                            <input type="text" value={invoice.challanvalue} name={invoice.challantext} className="form-control" placeholder={`Enter ${invoice.challantext}`}/>
                        </div>}
                    </div>
                </div>
            </div>
          </div>
          
        <div className="row row_divs">
              <table style={{padding:"4px"}}>
                <thead  style={{backgroundColor:"lightSkyblue"}}>
                <tr className="tds">
                  <td scope="col">#</td>
                  <td scope="col">Items</td>
                  <td scope="col">HSN</td>
                  <td scope="col">Unit</td>
                  <td scope="col">Dis</td>
                  <td scope="col">Qty</td>
                  <td scope="col">Price</td>
                  <td scope="col">GST</td>
                  <td scope="col">GST Amt</td>
                  <td scope="col">Amt Without gst</td>
                  <td scope="col">Amt with gst</td>
                </tr>
                </thead>
                <tr>
                <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModalCenter">
                    Add 
                  </button>
                </tr>
                <tr>
                  <td>srno</td>
                  <td>Name</td>
                  <td>code</td>
                  <td>unit</td>
                  <td>
                    <div className="input-group" >
                     <div className="input-group-prepend">
                     <input type="number" className="form-control" width={"12px"} />
                     </div>
                      <div className="input-group-append">
                        <select className="form-select">
                          <option>₹</option>
                          <option>%</option>
                        </select>
                      </div>
                    </div>
                  </td>
                </tr>
                <tr>
                  <td>Total</td>
                </tr>
                <tr>
                <td></td>
                  <td></td>
                  <td></td>
                  <td></td>
                  <td></td>
                  <td></td>
                  <td></td>
                  <td></td>
                  <td></td>
                  <td></td>
                  <td></td>
                </tr>
              </table>
            <div>
              <table>
              <tr>
                <td></td>
                  <td></td>
                  <td></td>
                  <td></td>
                  <td></td>
                  <td></td>
                  <td></td>
                  <td></td>
                  <td></td>
                  <td></td>
                  <td></td>
                </tr>
              </table>
            </div>
        </div>
          <div className="row row_div labels_size">
            <div>
              <table className="table table-bordered border-primary">
                <tr>
                  <td rowSpan={2} style={{verticalAlign:"middle",fontWeight:"600",textAlign:"center"}}>HSN/SAC</td>
                  <td rowSpan={2} style={{verticalAlign:"middle",fontWeight:"600",textAlign:"center"}}>Taxable Value</td>
                  <td colSpan={2} style={{verticalAlign:"middle",fontWeight:"600",textAlign:"center"}}>IGST Tax</td>
                  <td rowSpan={2} style={{verticalAlign:"middle",fontWeight:"600",textAlign:"center"}}>Amount With Tax</td>
                
                </tr>
                <tr>

                  <td style={{verticalAlign:"middle",fontWeight:"600",textAlign:"center"}}>Rate</td>
                  <td style={{verticalAlign:"middle",fontWeight:"600",textAlign:"center"}}>Amount</td>
                </tr>
                <tr>
                  <td style={{verticalAlign:"middle",fontWeight:"600",textAlign:"center"}}>Total</td>
                  <td style={{verticalAlign:"middle",fontWeight:"600",textAlign:"center"}}>0.000</td>
                  <td style={{verticalAlign:"middle",fontWeight:"600",textAlign:"center"}}></td>
                  <td style={{verticalAlign:"middle",fontWeight:"600",textAlign:"center"}}>0.000</td>
                  <td style={{verticalAlign:"middle",fontWeight:"600",textAlign:"center"}}>0.000</td>
                          
                </tr>
               
              </table>
              <table className="table">
              <tr style={{borderBottom:"1px solid blue"}}>
                  <th colSpan={5} ><input type="button" style={{border:"none"}} onClick={clickevent} value={additional?"+Additional Charges":"+Additional Charges"} /></th>
                </tr>
                </table>
                {additional!=false && <tr>
                  {addmore.map((val,ind)=>
                  <div className="row" key={ind} >
                    <div className="col-lg-2">
                      <div>
                        <label>Charges</label>
                        <select style={{fontSize:"small"}} name="charges" onChange={(e)=>handlechangeaddmore(e,val.id)}  className="form-select">
                          <option >select</option>
                          <option value="transportation" selected={val.charges=="transportation"?true:false}>Transportation</option>
                          <option value="packing" selected={val.charges=="packing"?true:false}>Packing</option>
                          <option value="wages" selected={val.charges=="wages"?true:false}>Wages</option>
                          <option value="other" selected={val.charges=="other"?true:false}>Other</option>
                        </select>
                      </div>
                      
                    </div>
                    <div className="col-lg-2">
                      <div>
                        <label>GST %</label>
                        <select style={{fontSize:"small"}}  onChange={(e)=>handlechangeaddmore(e,val.id)} name="gst" className="form-select">
                          <option>0</option>
                          <option value="0.25" selected={val.gst==0.25?true:false}>0.25</option>
                          <option value="3" selected={val.gst==0.3?true:false}>3</option>
                          <option value="5" selected={val.gst==0.5?true:false}>5</option>
                          <option value="12" selected={val.gst==12?true:false}>12</option>
                          <option value="18" selected={val.gst==18?true:false}>18</option>
                          <option value="28" selected={val.gst==28?true:false}>28</option>

                        </select>
                      </div>
                    </div>
                    <div className="col-lg-2">
                      <div>
                        <label>Amount</label>
                        <input type="number" value={val.amount} min={0} onKeyDown={blocking} onChange={(e)=>handlechangeaddmore(e,val.id)} name="amount" className="form-control"/>
                      </div>
                    </div>
                    <div className="col-lg-2">
                      <div>
                        <label>Gst Amount</label>
                        <input type="number" value={val.gstamt} onChange={(e)=>handlechangeaddmore(e,val.id)} name="gstamt" disabled className="form-control"/>
                      </div>
                      
                    </div>
                    <div className="col-lg-2">
                     <div>
                        <label>Net Amount</label>
                        <input type="number" value={val.netamt} onChange={(e)=>handlechangeaddmore(e,val.id)} name="netamt" disabled className="form-control"/>
                      </div>
                      
                    </div>
                    <div className="col-lg-2" style={{display:"flex",justifyContent:"center"}}>
                        {/* <label style={{color:"red",fontWeight:"700",marginTop:"20%"}}>Cancel</label> */}
                        {ind==0?"":<input type="button" style={{color:"red",fontWeight:"700",marginTop:"20%",border:"none",background:"transparent"}} onClick={(e)=>cancelfunc(val)} value={addmore?"Cancel":"Cancel"} />}
                    </div>
                  </div>)}

                    <div className="row">
                    <div>
                    <input type="button" style={{border:"none",color:"blue",background:"transparent"}} onClick={addmorefunc} value={addmore?"+Add More":"+Add More"} />
                    </div>
                  </div>
                  </tr>
                  }
            </div>

          </div>
          <div className="row row_div" style={{display:"flex",justifyContent:"space-between"}}>
          <div className="col-lg-6">
          <h8>{word?word:0}  Rupees Only/-</h8>
          </div>
            <div className="col-lg-6">
              <label>Total Amount</label>
              <input type="text" disabled  value={totals} className="form-control"/>
              
            </div>

          </div>
          
        </div>
      </div>
      <div class="modal fade" id="exampleModalCenter" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <div className="row" id="exampleModalLongTitle" style={{display:"flex",justifyContent:"center"}}>
          
          <div className="col-lg-3"><label style={{fontSize:"20px",fontWeight:"550"}}>Modal title</label></div>
          <div className="col-lg-9" style={{textAlign:"right"}}>
          
            <button type="button" class="btn btn-primary btn-outline" style={{marginRight:"10px"}} data-toggle="modal" data-target="#exampleModal">
                    Add New Item 
                  </button> 
                  <button type="button" class="btn btn-secondary" style={{marginRight:"10px"}} data-dismiss="modal">Close</button>
                  <button type="button" class="btn btn-danger" style={{float:"right",margin:"0px"}}>save</button>
                  {/* <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button> */}
                  </div>
                  <div className="row" >
                    <div className="col-lg-4" style={{display:"flex" ,justifyContent:"space-around",color:"blue",fontWeight:"600"}}>
                      <div><input type="radio" onChange={(e)=>setRadiobuttons({itemtype:e.target.name})} checked={radiobuttons.itemtype=="1"?true:false} name="1"/><label>Product</label></div>
                      <div><input type="radio" onChange={(e)=>setRadiobuttons({itemtype:e.target.name})} checked={radiobuttons.itemtype=="2"?true:false} name="2"/><label>Service</label></div>
                    </div>
                    <div className="col-lg-8"></div>

                  </div>
        </div>
      </div>
      {radiobuttons.itemtype=="2"?
      
      <div class="modal-body">
        <div className="row" >
          <div className="col-lg-6" >
              <label>Service Name</label>
              <input type="text" placeholder="Enter Product Name Here" className="form-control"/>
            
          </div>
          <div className="col-lg-6" style={{lineHeight:"200%"}}>
            <label>SAC</label>
            <input type="text" placeholder="Enter Product Name Here" className="form-control"/>
          </div>
         
          <div className="col-lg-6">
            <label>Service Description</label>
            <textarea rows={1} placeholder="Enter Product Name Here" className="form-control"/>
            
          </div>
          <div className="col-lg-6">
            <label>Sale Price</label>
            <input type="text" className="form-control"/>
          </div>
          <div className="col-lg-3" >
            <label>Tax</label>
            <input type="text" disabled className="form-control"/>
          </div>
          <div className="col-lg-9">
            <label>Expiry Date from</label>
            <div className="input-group">
            <input type="date" className="form-control"/>
            <input type="date" disabled className="form-control input-text"/>

              </div>
          </div>
        </div>
      </div>
      :
      <div class="modal-body">
        <div className="row" >
          <div className="col-lg-6" >
              <label>Product Name</label>
             <div className="form-group search_custom">
             <Autocomplete 
              items={Itemsname}
              getItemValue={(item) => item.productName}
              renderItem={(item, isHighlighted) => (
                <div className="search-list-inner" style={{
               background: isHighlighted ?
                   '#bcf5bc' : 'white',
               zIndex:99,
           }}  key={item.prodid} >{item.productName}
              
             </div>
           )}
           value={productvalue}
           onChange={(e)=>{
            setProductvalue(e.target.value);
            if(e.target.value=="")
              {
                setGstval("");
                setPartyvalue(""); 
                setCompanyname("");
                // allproductdetails["hnscode"]="";
                setAllproductdetails({
                  ["hnscode"]:"",
                  ["unit"]:"",
                  ["description"]:"",
                  ["saleprice"]:"", 
                  ["stockavailable"]:"",
                });
              }
            
           }}
           onSelect={(val,allItems) =>{
            setPartyvalue(allItems.partyName);
            setCompanyname(allItems.companyname);
            displaybranch(allItems.bpid);
            setProductdetail(allItems);
            setProductvalue(val);
           }}
           inputProps={{
             className: "form-control",
             placeholder: 'Search By Product Name',
             maxLength:"15", 
         }}
         />
              </div> 
          </div>
          <div className="col-lg-6" style={{lineHeight:"200%"}}>
            <label>HSN</label>
            <input type="text" disabled placeholder="HSN Code will be Here" value={allproductdetails.hnscode} className="form-control"/>
          </div>
          <div className="col-lg-6">
              <label>Unit</label>
              <input type="text" value={allproductdetails.unit} disabled placeholder="Unit will be Here" className="form-control"/>
          </div>
          <div className="col-lg-6">
            <label>Item Description</label>
            <textarea rows={1} value={allproductdetails.description?allproductdetails.description:"Not Mentioned"} disabled className="form-control"/>
          </div>
          <div className="col-lg-4">
            <label>Sale Price</label>
            <input type="number" disabled value={allproductdetails.saleprice} className="form-control"/>
          </div>
          <div className="col-lg-4" >
            <label>Tax</label>
            <input type="number" disabled className="form-control"/>
          </div>
          <div className="col-lg-4">
            <label>Stock</label>
            <input type="number" value={allproductdetails.stockavailable} disabled className="form-control"/>
          </div>
        </div>
      </div>
      }
      {/* <div class="modal-footer">
        <button type="button" class="btn btn-primary">Save changes</button>
      </div> */}
    </div>
  </div>
</div>

<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered modal-lg" style={{maxWidth:"95%"}} role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Add New Item</h5>
        {/* <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button> */}
        {item.value=="" ?
        <button type="button" class="btn btn-primary disabled" aria-disabled="true">Submit</button>
        :
        <button type="button" class="btn btn-primary" >Submit</button>
        }
        <button type="button" class="btn btn-secondary" name="cancel" onClick={cancelmodal} data-dismiss="modal">Close</button>
      </div>
      <div class="modal-body">
        <div className="row ">
        <div className="col-lg-3">
            <div>
            <label>Item Name</label>
            <input type="text" placeholder="Enter Item Name here" maxLength={30} onKeyPress={handlekeysfun} value={item.name}  onChange={handlegst} name="name" className="form-control"/>
            </div>
          </div>
          <div className="col-lg-3">
            <div>
            <label>Item Summary</label>
            <input type="text" placeholder="Enter Item summary"  onKeyPress={handlekeysfun} value={item.summary}  onChange={handlegst} name="summary" className="form-control"/>
            </div>
          </div>
          <div className="col-lg-3">
            <div>
            <label>Brand/Company</label>
            <input type="text" placeholder="Enter Brand/Company" name="brand" maxLength={30} onKeyPress={handlekeysfun} value={item.brand}  onChange={handlegst}  className="form-control"/>
            </div>
          </div>
          <div className="col-lg-3">
            <div>
            <label>Item/Product Code</label>
            <input type="text" placeholder="Enter Item/Product Code" maxLength={30} onKeyPress={handlekeysfun} value={item.productcode}  onChange={handlegst} name="productcode" className="form-control"/>
            </div>
          </div>
          </div>
          <div className="row">
            <div className="col-lg-3">
              
             <label>Size</label>
              <input type="text"  value={item.size}  onChange={handlegst} name="size" className="form-control"/>

            </div>
            <div className="col-lg-3">
              <label>Color</label>
              <input type="text"  value={item.color}  onChange={handlegst} name="color" className="form-control"/>
            </div>
            <div className="col-lg-3">
              <label>Purchase Price</label>
              <div className="input-group">
                <input type="text" className="form-control"/>
                <select className="input-group-text form-select" name="purchaseprice" onChange={handledrop}>
                  <option>Exclusive</option>
                  <option>Inclusive</option>
                </select>
              </div>
            </div>
            <div className="col-lg-3">
              <label>Sales Price</label>
              <div className="input-group">
                <input type="text" className="form-control"/>
                <select className="input-group-text form-select" name="salesprice" onChange={handledrop}>
                  <option>Exclusive</option>
                  <option>Inclusive</option>
                </select>
              </div>
            </div>
          </div>
          <div className="row">
            <div className="col-lg-3">
            <label>Unit<span style={{color:"red",fontSize:"small"}}>Required *</span></label>
            <select className="form-select"  value={item.unit} name="unit" onChange={handlegst}>
              <option>select</option>
              {unit!=undefined && unit.length>0 && unit.map((val,index)=>
              <option key={index} value={val.sno} selected={item.unit==val.unitvalue?true:false}>{`${val.unitname},${val.unitvalue}`}</option>)}
            </select>
            </div>
            <div className="col-lg-3">
            <label>HSN Code</label>
            <input type="number" placeholder="Enter Hsn code here" maxLength={10} onKeyPress={handlekeysfun} value={item.hsn}  onChange={handlegst} name="hsn" className="form-control"/>

            </div>
            <div className="col-lg-3">
            <label>Gst %</label>
            <select className="form-select" name="gst"  onChange={handlegst}>
              <option >select</option>
              {gstdisplay!=undefined && gstdisplay.length>0 && gstdisplay.map((val,ind)=>
              <option key={ind} value={val.sn} selected={val.igst==item.gst?true:false}>{val.igst}</option>)
              }
            </select>

            </div>
            <div className="col-lg-3">
              <label>Batch Number</label>
              <input type="number" className="form-control"/>
            </div>
          </div>
          <div className="row">
            <div className="col-lg-3">
              <label>Size</label>
              <input type="number" className="form-control"/>
            </div>
            <div className="col-lg-3">
              <label>Stock Quantity as of</label>
              <input type="date" max={moment(new Date()).format("DD-MM-YYYY")} className="form-control"/>
            </div>
            <div className="col-lg-3">
              <label>Expiry in </label>
              <input type="date" className="form-control"/>
            </div>
            <div className="col-lg-3">
              <label>Description</label>
              <textarea type="text" className="form-control"/>
            </div>
          </div>
      </div>
    </div>
  </div>
</div>
    </>
  );
}
export default Demo3;
