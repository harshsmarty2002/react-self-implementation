import React, { useMemo } from "react";
import { useEffect } from "react";
import axios from "axios";
// import "./css/custom.css";
import "./demo2.css";
import {TablePagination} from '@material-ui/core';
import { API, callAPI } from "../../Config/apiUtil";
import { apiUrls } from "../../Config/apiUrl";
import Cookies from "js-cookie";
import Image from "../components/image/excel.png";
import Gst from "./Gst.jpg";
import Without from "./Without.png";
import ReactImageZoom from "react-image-zoom";

import ReactHTMLTableToExcel from "react-html-table-to-excel";

import { CSVLink } from "react-csv";      //***********Normal Excel Download****** */ //

import { useState } from "react";

function Demo1() {
  
  const [data, setData] = useState([]);
  const [column,setColumn]=useState({value:["Sr_no","Product_id","Photo","Category","Price"]});
  const [radio,setRadio]=useState("");
  const [rowsPerPage,setRowsPerPage]=useState(5);
  const [page,setPage]=useState(0);
  const [user,setUser]=useState([]);
  const useSortableData=(data1,config=null)=>{

    const [sortConf,setSortConf]=useState(config);

    const sortedItems=useMemo(()=>{

      const sortable=[...data1];
      
      if(sortConf!=null)
      {
          sortable.sort((a,b)=>{
            if(a[sortConf.key] < b[sortConf.key])
            {
              return sortConf.direction === 'ascending' ? -1 : 1;
            }
            if(a[sortConf.key] > b[sortConf.key])
            {
              return sortConf.direction === 'ascending' ? 1 : -1;
            }
            return 0;
          });
        }
        return sortable;
    },[data1,sortConf]);

    const sortes=(i)=>{
      let key=i;
      let direction="ascending";
      
      if(sortConf && sortConf.key===key && sortConf.direction==="ascending")
      {
        direction="decending";
      }
      setSortConf({key,direction});
    };
    return {items:sortedItems,sortConf,sortes};

    
  }
  
  const paginatedusers = (user != undefined && user.length > 0) ? (user)
		.slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage) : [];

  const {items,sortConf,sortes}=useSortableData(paginatedusers);


  const bid = Cookies.get("bid");
  const [theme, setTheme] = useState({});
  const props = { width: 300, height: 250, zoomWidth: 400, img: radio=="withgst"?Gst:Without};
  const tableData =async() => {
    let url = "https://api.webroot.net.in/products.php";
    await axios.get(url).then((result) => {
      setData(result.data);
      console.log(result.data);
      setUser(result.data)
    });
  };

  const displaytheme = async (bid) => {
    let query = { bid: bid };
    try {
      const apiResponse = await callAPI(
        apiUrls.get_invoice_themes_by_bid,
        query,
        "GET"
      );
      
    setTheme(apiResponse.data.value);
    } 
    catch (error) {
      console.log(error);
    }
  };
  
  useEffect(() => {
    displaytheme(bid);
  }, []);

  useEffect(() => {
    tableData();
  }, []);

  const handleColumn=(e)=>{
    
    let arr=column.value;
    let found=arr.indexOf(e.target.value);
    
    if(found > -1)
    {
      arr.splice(found,1);
    }
    else{
      arr.push(e.target.value);

    }
    setColumn({
      value:arr
    })

  }
  /************************Advance Excel Download************************** */

  // const ExcelFile=ReactExport.ExcelFile;
  // const ExcelSheet=ReactExport.ExcelFile.ExcelSheet;

  // const datasets=[
  //   {
  //     column:[
  //       {title:'Srno',style:{font:{sz:18,bold:true},width:{wpx:"12px"}}},//width in pixel
  //       {title:'Product Name',style:{font:{sz:18,bold:true},width:{wch:"25px"}}},//width in characters
  //       {title:'Price',style:{font:{sz:18,bold:true},width:{wpx:"18px"}}},
  //       {title:'Url',style:{font:{sz:18,bold:true},width:{wpx:"40px"}}},
  //           ],
  //     data:data.map((data)=>[
  //       {value:data.pid},
  //       {value:data.pname},
  //       {value:data.price},
  //       {value:data.photo},
  //     ])

  // }
  // ]

  /************************Advance Excel Download************************** */

  /************************Normal Excel Download************************** */
  const headers=[
    {label:'Sr_no*',key:'pid'},
    {label:'Category*',key:'pname'},
    {label:'Price*',key:'price'},
    {label:'Photo url',key:'photo'},
  ]
  const csvReoprt={
    filename:'Product.csv',
    headers:headers,
    data:data,
  }

  ///************************Normal Excel Download************************** *///
  
  const handleChangeRowsPerPage=(event)=>{

    console.log(parseInt(event.target.value,10));
    setRowsPerPage(parseInt(event.target.value,10));
    setPage(0);

    // console.log(parseInt(event.target.value,5));

  }

  const handleChangePage=(event,newpage)=>{

    setPage(newpage);
    
  }
  function getdata()
  {


  }

  useEffect(()=>{getdata();},[]);

  return (
    <>
      <div className="dashboard_body_content add_item_bg">
        <div className="dashboard_container">
          <div className="input-group">
          
            <input className="form-control" placeholder="Select Table headings Here" />
             <div class="dropdown">
             
             <button class="btn btn-primary dropdown-toggle" type="button" id="dropdownmenu"  data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Chose Items</button>
              <ul class="dropdown-menu" aria-labelledby="dropdownmenu">
                <li class="dropdown-item"><input  type="checkbox" onChange={(e)=>handleColumn(e)} value="Sr_no" checked={column.value.indexOf("Sr_no") > -1?true:false}/>Sr no</li>
                <li class="dropdown-item"><input type="checkbox" onChange={(e)=>handleColumn(e)}  value="Product_id" checked={column.value.indexOf("Product_id") > -1?true:false} />Product id</li>
                <li class="dropdown-item"><input type="checkbox" onChange={(e)=>handleColumn(e)}  value="Photo" checked={column.value.indexOf("Photo") > -1?true:false}/>Photo</li>
                <li class="dropdown-item"><input type="checkbox" onChange={(e)=>handleColumn(e)}  value="Category" checked={column.value.indexOf("Category") > -1?true:false}/>Category</li>
                <li class="dropdown-item"><input type="checkbox" onChange={(e)=>handleColumn(e)}  value="Price" checked={column.value.indexOf("Price") > -1?true:false}/>Price</li>
              </ul>
             </div>
          </div>
          {/* <div>
            <ExcelFile 
            filename="Advance Formatted Excel "
            element={<button type="button" className="btn btn-outline-danger float-right">Download Excel Here</button>}

            >  
              <ExcelSheet datasets={datasets} name="Report"/>
            </ExcelFile>
          </div> */}
         <div>
          <h1>Add Inventory Mnagement and Company setup</h1>

         </div>
         
       <div className="row_div">
       <div className="py-2" style={{float:"right"}}>
          <ReactHTMLTableToExcel 
             
             className="btn btn-outline-success"
             table="table-data"
             filename="Product"
             sheet="ProductData"
             buttonText="Download as XLS"
            ><img src={Image}/></ReactHTMLTableToExcel>
          <CSVLink {...csvReoprt} className="btn btn-outline-primary" ><img src={Image}/>Download Csv</CSVLink>

          </div>
       <table id="table-data"
            className="table table-striped"
            style={{ textAlign: "center" }}>
            <thead style={{ backgroundColor: "gray" }}>
           <tr>

            {column.value.indexOf("Sr_no") > -1 ? 
              <th>Sr.no
              </th> :"" }
           
             {column.value.indexOf("Product_id") > -1 ? 
             <th><button 
             onClick={(e)=>sortes(e.target.name)}
             name="pid"
             >Product id
             </button>
             </th>:"" }
             
             {column.value.indexOf("Photo") > -1 ? 
              <th><button 
              onClick={(e)=>sortes(e.target.name)}
              name="photo"
              >Photo
              </button>
              </th>:"" }
            

             {column.value.indexOf("Category") > -1 ? 
              <th><button 
              onClick={(e)=>sortes(e.target.name)}
              name="Category"
              >Category</button>
              </th>:"" }

             {column.value.indexOf("Price") > -1 ?
              <th><button 
              onClick={(e)=>sortes(e.target.name)}
              name="Price"
              >Price</button>
              </th> :"" }
           </tr>
            </thead>
            <tbody>

              {items.map((r, ind) => (
                <tr key={ind}>
                  {column.value.indexOf("Sr_no") > -1 ?<td>{ind + 1}</td>:""}                  
                  {column.value.indexOf("Product_id") > -1 ?<td>{r.pid}</td>:""}
                  {column.value.indexOf("Photo") > -1 ? <td>
                    <img
                      src={r.photo}
                      style={{
                        width: "34px",
                        height: "34px",
                        borderRadius: "8px",
                      }}
                    />
                  </td>
                  :
                  ""}
                  {column.value.indexOf("Category") > -1 ? <td>{r.pname}</td>:""}
                  {column.value.indexOf("Price") > -1 ? <td>{r.price}</td>:""}
                </tr>
              ))}
              <tr>
                <td></td>
                <td colSpan={4}> 
                {paginatedusers!=undefined && paginatedusers.length>0 && (
                  <TablePagination

                  rowsPerPageOptions={[5, 10,100]}
                  component="div"
                  count={user.length} 
                  rowsPerPage={rowsPerPage}
                  page={page}
                  onPageChange={handleChangePage}
                  onRowsPerPageChange={handleChangeRowsPerPage} 
                />
                )}
              </td>
              </tr>
            </tbody>
          </table>
       </div>
              <div className="row row_div">
                <div className="col-lg-4">
                  <div className="row_div">
                    <div style={{textAlign:"center"}}> <img src={Gst} height="200px"style={{width:"100%"}} /><br/>
                    <input type="radio" onChange={(e)=>setRadio(e.target.value)} checked={radio=="withgst"?true:false} value="withgst" />
                    <label><strong>With Gst</strong></label>
                    </div>
                  </div>
                </div>
                <div className="col-lg-4">
                  <div className="row_div">
                  <div style={{textAlign:"center"}}>         
                 <img src={Without} height="200px" style={{width:"100%"}} /><br/>
                  <input type="radio" onChange={(e)=>setRadio(e.target.value)} checked={radio=="withoutgst"?true:false} value="withoutgst"/> 
                    <label><strong>Without Gst</strong></label>
                  </div>
                  </div>
                </div>
                <div className="col-lg-4"></div>
              </div>
            <div className="row row_div">
            <div className="col-lg-6" style={{ backgroundStyle: "red" }}>
              <ReactImageZoom {...props}/>
            </div> 
            <div className="col-lg-6"> 
            </div>     
            </div>
          
        </div>
      </div>
    </>
  );
}
export default Demo1;
