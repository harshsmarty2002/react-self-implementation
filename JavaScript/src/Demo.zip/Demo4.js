
import React, { useState, useEffect,useRef } from 'react';
import { errorMessage, successMessage } from '../../Comman/AlertMassge';
import { apiUrls } from '../../Config/apiUrl';
import { callAPI } from '../../Config/apiUtil';
import {Dialog,DialogTitle,DialogContent,DialogActions,Button,Box,IconButton,Typography} from '@material-ui/core';
import Cookies from 'js-cookie';
import { useDispatch ,useSelector} from 'react-redux'
import { Sowcatagory } from '../../Redux/Redux/Action/Action';
import { useNavigate } from 'react-router-dom';
import Routelink from '../../Comman/routelink';
import Loder from '../../loder/loder';

export default function Demo4() {
	const navigate = useNavigate();
	const dispatch = useDispatch()
	const inputRef = useRef();
	const subcatRef=useRef();
	let bid = Cookies.get('bid');
	const [fillter, setfillter] = useState([])
	const [deleteCat, setDeleteCat] = useState(false);
	const [deleteCatId, setDeleteCatId] = useState(null)
	const [deleteSubCat, setDeleteSubCat] = useState(false);
	const [deleteSubCatId, setDeleteSubCatId] = useState(null)
	const [companydata, setCompanydata] = useState({})
	const [data, setData] = useState({})
	const [subcat, setSubcat] = useState({})
	const [notregister, setNoregister] = useState(null)
	const [subcatvald, setsubcatvald] = useState(null)
	const [isloader, setIsloader] = useState(false)
	const [errors, setErrors] = useState({})
	const [suberrors, setSubErrors] = useState(false)
	const [search, setearch] = useState(false)
	const [categorydata, setcategorydata] = useState({})

	const handleChange = (e) => {
		
		if (e.target.name == "categoryname"){
				errors.categoryname = undefined;
				setNoregister(null)
		}

		setCompanydata((companydata) => ({ ...companydata, [e.target.name]: e.target.value }))
	 }

	 const handleChangecat = (e,cateId) => {
		if (e.target.name == "categoryname"){
			setsubcatvald(null)
	}
		
		setSubcat((subcat) => ({ ...subcat,['parentcatid']:cateId, [e.target.name]: e.target.value }))
	 }
	 
	 const handleEditChange = (e,cateId) => {
		console.log(e);
		setData((data) => ({ ...data,['sno']:cateId, [e.target.name]: e.target.value }))
	 }

	 const handleEditCat = (e,cateId) => {
		setcategorydata((data) => ({ ...data,['sno']:cateId, [e.target.name]: e.target.value }))
	 }
	
	 
	 function Validate() {
		let error = {};
		let validate = true;
		
		if (!companydata.categoryname) {
			validate = false;
			error["categoryname"] = "Required";
		 }

		 setErrors(error)
		 return validate;
	 }

	 function Validatesub() {
		let validates = true;
		if (!subcat.categoryname) {
			validates = false;
			errorMessage("Required")
		 }
		 return validates;
	 }

	 const formdata = {
		categoryname: companydata.categoryname,
	     bid : bid
	 }

	 //console.log("formdata",formdata)
	
	const Category = async () => {
		try {

		   const apiResponse = await callAPI(apiUrls.create_category_subcategory, {}, "POST", formdata);
            
		   console.log('test',apiResponse.data);

		    if (Object.keys(apiResponse.data).length > 0) {
			if (apiResponse.data.status == "category already exist.") {
				setIsloader(false)
				setNoregister('Already Exists');
			} 
			else {
				setIsloader(false)
				displaycategory();
				setNoregister(null)
				successMessage('Category created successfully')
				inputRef.current.value = "";
				setCompanydata({})
			}	
		   }
		} catch (err) {
		   console.error(err);
		}
	 };

	 function onsubmit (){
		 if (Validate()){
			setIsloader(true)
			Category()
			inputRef.current.focus();
		 }
	 }

	 const displaycategory = async () => {
		try {
			setIsloader(true)
			let query={bid:bid}
		   const apiResponse = await callAPI(apiUrls.category_subcategory_display,query, "GET");
		     setIsloader(false)
				if (apiResponse.data.value != undefined && apiResponse.data.value.length > 0) {
					
			      dispatch(Sowcatagory(apiResponse.data.value))
				  setfillter(apiResponse.data.value)
				  setSubErrors(false)
				  setearch(true)
				}
			
		else{
			dispatch(Sowcatagory([]))
			setfillter([])
			setSubErrors(true) 
			setearch(false)
		}
			 
		//    }
		} catch (err) {
		   console.log(err)
		}
	 }
	//  console.log(fillter);
  
	 useEffect(() => {
		displaycategory().then(res => checkPermission());
	 }, []);
  

	 const checkPermission = async () => {
		let permission = JSON.parse(localStorage.getItem('permission'));
		if (permission.length > 0) {
			permission = permission.map(item => item.subMenus).flat();
			let getPermissionObj = permission.find(item => item.url === 'manage_category');
			console.log(getPermissionObj)
			if (!getPermissionObj.isSubMenuPermission) {
				errorMessage("you have no permission")
				return navigate(`/dashboard`);
			}
		}
	}
	
	const data1 = {
		categoryname: data.categoryname,
		sno: data.sno,
	     bid : bid
	 }

	const Category1 = async () => {
		try {
		   const apiResponse = await callAPI(apiUrls.create_category_subcategory, {}, "POST", data1);
		   if (Object.keys(apiResponse.data).length > 0) {
			if (apiResponse.data.status == "category already exist.") {
				setIsloader(false)
				errorMessage('Already Exists');
			} 
			else{
				setIsloader(false)
				successMessage('Category updated successfully ')
				displaycategory();
				setData({});
			}	 
		   }
		} catch (err) {
			
		   console.error(err);
		}
	 };

	 const data2 = {
		 categoryname:subcat.categoryname,
	     bid:bid,
		 parentcatid:subcat.parentcatid,
	 }

	const Category2 = async () => {
		try {
		   const apiResponse = await callAPI(apiUrls.create_category_subcategory, {}, "POST", data2);
            //console.log('test',apiResponse.data)
		   if (Object.keys(apiResponse.data).length > 0) {
			setIsloader(false)
			if (apiResponse.data.status == "category already exist.") {
				setsubcatvald('Subcategory Already Exists');

			} else {
				setIsloader(false)
				subcatRef.current.value = "";
				displaycategory();
				successMessage('Sub category created successfully ')
				setsubcatvald(null)
				setSubcat((subcat) => ({ ...subcat,['categoryname']:"" }))
			}
			
		   }
		} catch (err) {
		   console.error(err);
		}
	 };
	 
	 function update (){
		setIsloader(true)
		Category1()
		
	 }

	
	 const editCategroy = (data) =>{
		errors.categoryname = undefined;
			setNoregister(null)
			inputRef.current.value = "";
			setCompanydata({});
		setData(data)
	 }

	 const cancelclass = ()=>{
		setData({})
	 }
	 const editsubCategroy = (data) =>{
		setcategorydata(data)
	 }

	 const cancelsub =()=>{
		setcategorydata({})
	 }

	 const closemodel = ()=>{
		errors.categoryname = undefined;
		setNoregister(null)
		setText(false)
		setcategorydata({})
	 }

	// console.log(categorydata)

	 const [text, setText] = useState(false)
	 function show(data) {
		errors.categoryname = undefined;
		setNoregister(null)
		inputRef.current.value = "";
	    setCompanydata({})
	    setText(true)
	    setSubcat({...data,['categoryname']:""})
	    setsubcatvald(null)
	 }
      function addsubcat(){
		if(Validatesub()){
			setIsloader(true)
			Category2();
		subcatRef.current.focus();
		}
		
}

const data4 = {
	categoryname: categorydata.categoryname,
	sno: categorydata.sno,
	bid : bid,
	parentcatid: categorydata.parentcatid,

}

 //console.log(categorydata)

const Category4 = async () => {
	try {
	   const apiResponse = await callAPI(apiUrls.create_category_subcategory, {}, "POST", data4);
		//console.log('test',apiResponse.data)
	   if (Object.keys(apiResponse.data).length > 0) {
		if (apiResponse.data.status == "category already exist.") {
			setIsloader(false)
			errorMessage('Subcategory Already Exists');

		}
		else{

			setIsloader(false);
			displaycategory();
			successMessage('Sub category updated successfully');
			setcategorydata({});
		}
	   }
	} catch (err) {
	   console.error(err);
	}
 };

 function updatesubcatname(){

	setIsloader(true)
	Category4();

	//setText(false)
 }

 const catagoryGet = useSelector((state) => state.Catogrycount.catogry)

	const deletehandler1 = (id) => {
		errors.categoryname = undefined;
		setNoregister(null)
		inputRef.current.value = "";
		setCompanydata({});
		setDeleteCat(true);
		setDeleteCatId(id);
	}

	const  deletecathandler = async (id)=>{
		setDeleteCat(false)
		setIsloader(true)
       let query={catid:id,bid:bid}
		const apiResponse =  await callAPI(apiUrls.delete_cat_subcat,query,"GET");
			   // alert("delete")
					if (Object.keys(apiResponse.data).length > 0) {
						
						if (apiResponse.data != undefined && Object.keys(apiResponse.data).length > 0) {
							
							setIsloader(false)
							errorMessage("category is deleted successfully")
							displaycategory();
						}
					}
	}

	const cancelDeleteBox = () => {
		setDeleteCat(false)
		setDeleteCatId(null)
	}

	const deletehandler2 = (id) => {
		setDeleteSubCat(true)
		setDeleteSubCatId(id)
	}
	const  deletecatsubcathandler = async (id)=>{
		setDeleteSubCat(false)
		setIsloader(true)
		let query={subcatid:id,bid:bid}

		const apiResponse =  await callAPI(apiUrls.delete_subcategory,query,"GET");
		// alert("delete")

		if (Object.keys(apiResponse.data).length > 0) {
			
			if (apiResponse.data != undefined && Object.keys(apiResponse.data).length > 0) 
			{
				setIsloader(false)
			    errorMessage("Subcategory is deleted successfully")
			    setsubcatvald(null)
			    displaycategory();
			}
		}
	}

	const cancelDeleteBox2 = () => {
		setDeleteSubCat(false)
		setDeleteSubCatId(null)
	}

	const userFilter =async (value) => {
		try {
			if(value !==""){
			let query = { bid:bid, q:value}
			//console.log(query)
			const apiResponse = await callAPI(apiUrls.search_category_subcategory, query, "GET");
			if (apiResponse.data.value != null && apiResponse.data.value.length>0){
				console.log(apiResponse.data.value);
				dispatch(Sowcatagory(apiResponse.data.value))
				setSubErrors(false)
			}
			else{
				dispatch(Sowcatagory([]))
				setSubErrors(true)
			}	
			}
			else{
				dispatch(Sowcatagory(fillter))
				setSubErrors(false)
			}	
		
		} catch (err) {
			console.log(err)
		}
	  }

	 
	  function blockspecialchar(inputtxt)
	  {
	   var specials = /^[A-Za-z 0-9_.-\s]+$/i;
	   if(inputtxt.key.match(specials))
		 {
		  return true;
		 }
	   else
		 {
		 inputtxt.preventDefault();
		 }
	  }
	  console.log(data);
    return (
    <>
		<div class="dashboard_body_content add_item_bg">
		<div class="dashboard_container">
		<Routelink menuid="GM003" main_heading="MANAGE CATEGORY & SUBCATEGORY" heading_pages="Inventory or Products

" icon="fa fa-cubes picon" id="GSM0007" subheading="Manage Category & Subcategory"/>
			<div class="add__category mt-4 ">
			<div className="add__category">
				<div className="categorry  search_design">
					<div className="category invoice_form add_customer bg-white category_form">
						<div className="add_button">
						
							<div className="top_heading_search d-flex align-items-center add_category_input">
								<div className='label_category'>
									<label className='d-block'>Add Category</label>
									{errors.categoryname && <span className="errors">{errors.categoryname}</span>}
									{notregister && <span className="errors" >{notregister}</span>}
								</div>
								
								<div className='top_category_search'>
									<input type="text"  maxLength={140}  ref={inputRef} name='categoryname' onKeyDown={blockspecialchar} onChange={handleChange} className="form-control bg-grey me-3"  placeholder="Enter Category Name"/>
									{text == false ? <button className="btn btn-primary ms-auto text-white" onClick={onsubmit}>Save</button>
									:
									<button className="btn btn-secondary ms-auto text-white disabled">Save</button>}
								</div>
							</div>
{search &&
							<div className="add_button add_stock manage_item-button mt-4">
						<div className="d-flex magn_search align-items-center">
											<div className="input-form">
												<img src="/image/manage Search Icon.png" className="img-fluid" alt="" id="exampleFormControlInput1" />
												<input type="text" onKeyDown={blockspecialchar} onChange={e => userFilter(e.target.value)} className="form-control" id="exampleFormControlInput1" placeholder="Search Category..." />
											</div>
                                           </div>
										</div>
						}
						</div> 
						{isloader && 
                 <Loder/>
              }
			  {suberrors && <div className="error_msg_norecod">No Record Found</div>}
						{(catagoryGet != undefined && catagoryGet.length > 0) && catagoryGet.map((val, ind) => (
							<div className="new-category ">
							<div className="categgg d-flex justify-content-between">
								<div className="add_categ">
									<div>
										<h3 key={ind} className="d-flex align-items-center mb-2"><img src="/image/Folder.png" alt=""/>
										<span className='Category_input'>
									{(data.sno !=undefined && data.sno == val.sno) 
									? 
									<input type="text" maxLength={140} className={data !=undefined && "edit_name"} onChange={(e)=>handleEditChange(e,val.sno)} name='categoryname' value={data.categoryname}/>
									:
									<input type="text"  name='categoryname' onClick={()=>editCategroy(val)} value={val.categoryname}/>}
									</span> 
									{(data.sno !=undefined && data.sno == val.sno) ? <a href="javascript:void(0)" className="edit_btn" onClick={cancelclass}><i class="fa fa-times" style={{color:"red"}} aria-hidden="true"></i> Cancel </a>:
									<a href="javascript:void(0)" className="edit_btn" onClick={()=>editCategroy(val)} ><img src="/image/small-edit.png" alt="" /> Edit </a>
									}
									</h3>
										<p>Subcategory:{val.subCategories.length}</p>
	
									</div>
									<div className="add_categ_button d-flex">
									{(text === true && (subcat.sno !=undefined && subcat.sno == val.sno)) 
									?	
									""
									:
									<button type='submit'  className="edit edit_1 me-3" onClick={()=>show(val)} ><img src="/image/fi-rr-edit.png" alt=""  /> Add / Edit Subcategory</button>	}	</div>
								</div>
								<div className="add_categ_button d-flex">
								{(data.sno !=undefined && data.sno == val.sno) 
								?	
									<button className="btn button_save ms-auto text-white" onClick={update}>Update</button>:
									(text == true && (subcat.sno !=undefined && subcat.sno == val.sno)) ? <button type='submit' onClick={()=>closemodel()} className="delete">Close</button>
									:<button type='submit'  onClick={() => deletehandler1(val.sno)}  className="delete"><img src="/image/Delete.png" alt=""/></button>
									}
									{(text === true && (subcat.sno !=undefined && subcat.sno == val.sno)) ?	""
									:	<button type='submit' onClick={()=>show(val)} className="edit d-lg-none me-3"><img src="/image/fi-rr-edit.png" alt=""/>    Add / Edit Sub Category</button>	}	
								</div>
							</div>
							
							{text && (subcat.sno !=undefined && subcat.sno == val.sno)
									&& 
									<>
									<div className="show_sub_cat">
									<div className="position-relative add_sub_cat fix_input mb-4">
									<input type="text" ref={subcatRef} className="form-control" name='categoryname' maxLength={140}  onChange={(e)=>handleChangecat(e,val.sno)}  placeholder="Enter Subcategory Name"/>
									<div className="add_categ_button add">
										<a href="javascript:void(0)" className="edit edit_add" onClick={addsubcat}>Add</a>
									</div>
									
								</div>
								
									{subcatvald && <p className="errors" >{subcatvald}</p>}
									{(val.subCategories != undefined && val.subCategories.length > 0) && val.subCategories.map((value, ind) => (
									
								<div key={ind} className={categorydata.sno !=undefined && categorydata.sno == value.sno ? "position-relative add_sub_cat edit_subcat":"position-relative add_sub_cat"}>
									<p>{ind+1}</p>
									{(categorydata.sno !=undefined && categorydata.sno == value.sno) ? 
										<input type="text" className="form-control" name='categoryname' value={categorydata.categoryname}  maxLength={140}  onChange={(e)=>handleEditCat(e,value.sno)} />:
									<input type="text" className="form-control" value={value.categoryname} onClick={()=>editsubCategroy(value)} />}
									{(categorydata.sno !=undefined && categorydata.sno == value.sno) ? 	<a href="javascript:void(0)" style={{color: "#555", fontWeight: "500",fontSize: "14px"}} onClick={cancelsub} ><i class="fa fa-times" style={{color:"red"}} aria-hidden="true"></i> Cancel</a>:
									<a href="javascript:void(0)" className="edit_mobile" onClick={()=>editsubCategroy(value)}  ><img src="/image/small-edit.png"  alt=""/></a>
									 }

									{(categorydata.sno !=undefined && categorydata.sno == value.sno) ?<a href="javascript:void(0)" className="edit_mobile up" onClick={updatesubcatname} >Update</a>:
									<a href="javascript:void(0)" className="delete upd"  onClick={() => deletehandler2(value.sno)} ><img src="/image/Delete.png" alt=""/></a>}
								</div>
							))}
							
								</div>
							</>
									}
							
						</div>
                    ))}
					</div>
				</div>
			</div>
			</div>
		</div>
	</div>
			<Dialog open={deleteCat} maxWidth="sm" width={25}>
				<DialogTitle>Delete Category</DialogTitle>
					<Box position="absolute" top={0} right={0}>
						<IconButton onClick={() => cancelDeleteBox()}>
							<i class="fa fa-close" />
						</IconButton>
					</Box>
					<DialogContent>
						<Typography>Are you sure to delete Category?</Typography>
					</DialogContent>
					<DialogActions>
						<Button color="primary" variant="contained" onClick={() => cancelDeleteBox()}>
							Cancel
						</Button>
						<Button color="secondary" variant="contained" onClick={() => deletecathandler(deleteCatId)} >
							Confirm
						</Button>
					</DialogActions>
				</Dialog>
	
				<Dialog open={deleteSubCat} maxWidth="sm" width={25}>
					<DialogTitle>Delete Sub Category</DialogTitle>
						<Box position="absolute" top={0} right={0}>
							<IconButton onClick={() => cancelDeleteBox2()}>
								<i class="fa fa-close" />
							</IconButton>
						</Box>
					<DialogContent>
						<Typography>Are you sure to delete Sub Category?</Typography>
					</DialogContent>
					<DialogActions>
						<Button color="primary" variant="contained" onClick={() => cancelDeleteBox2()}>
							Cancel
						</Button>
						<Button color="secondary" variant="contained" onClick={() => deletecatsubcathandler(deleteSubCatId)} >
							Confirm
						</Button>
				</DialogActions>
			</Dialog>

    </>
    )
}


