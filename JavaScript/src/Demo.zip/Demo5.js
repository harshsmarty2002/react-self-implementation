import React from "react";
import { useState} from "react";
import "./demo2.css";
import { API, callAPI } from '../../Config/apiUtil';
import { apiUrls } from '../../Config/apiUrl';
import Cookies from "js-cookie";
import { useEffect } from "react";

function Demo5()
{
    const [topmenu,setTopmenu]=useState([]);
    
    // const [menu,setMenu]=useState([]);
    
    const [submenu,setSubmenu]=useState([]);
    const [menu,setMenu]=useState([]);
    const bid=Cookies.get('bid');
    
    async function menues(){
        let query = { bid: bid }	
        const apiResponse = await callAPI(apiUrls.config_fav_sub_menu_display_edit, query, "GET");
        
         setTopmenu(apiResponse.data.value);
    }

    function handlesubmenus(e,id)
    {

        const found = menu.filter(element=>element.menuid==id);
        let foundlength=found[0];
        if(found!=undefined)
        {
            let subs=foundlength.submenuid;
            
            let ind=subs.indexOf(e.target.value);
            if(ind > -1)
            {
               
                subs.splice(ind,1);
                let findind=menu.findIndex((values)=>{return values.menuid==id});
                let obj={...foundlength,["submenuid"]:subs}
                menu[findind]=obj;
                setMenu([...menu]);
                if(subs==0)
                {
                    const updatedEle = menu.filter((val) => val.menuid!== id)
					setMenu(updatedEle); 	
                }
              
            }
            else
            {
            subs.push(e.target.value)
            let findind=menu.findIndex((values)=>{return values.menuid==id});
            let obj={...foundlength,["submenuid"]:subs}
            menu[findind]=obj;
            setMenu([...menu]);
            }
           
        }
       
    }
    console.log(menu);
    function handleMenu(e){
        let found=menu.findIndex(element=>element.menuid==e.target.value);
        if(found > -1)
        {
            let filters=menu.filter(element=>element.menuid!=e.target.value);
            setMenu(filters);
        }
        else{
            const menuitems=topmenu.find(item=>item.menuId==e.target.value);
           const obj={
                menuid:e.target.value,
                submenuid:menuitems.subMenus.map(item=>item.subMenuId)
            }
            const updatedArray=[...menu,obj];
            setMenu(updatedArray);
        }   
    }
    
    const permission = menu.map(item => item.menuid).flat();
    
    console.log(permission);

    function handlepostuser(){

        // let permission=localStorage.getItem('permission');
        localStorage.setItem('permission',JSON.stringify(menu));
        
    }
    function handleLocal(){
        localStorage.clear('permission');
    }
    useEffect(()=>{menues();},[]);
	
    return(
        <>
        <div className="dashboard_body_content add_item_bg">
        <div className="dashboard_container">
            <div className="container">
                <h5>Select Menues and Submenus</h5>
                <div className="row_div">
                    <div className="row">
                       {topmenu.map((element,index)=>
                        <div key={index}>
                            <h6><strong>{element.menuName}</strong><input type="checkbox" value={element.menuId} className="check-menu" onChange={(e)=>handleMenu(e)} checked={menu.find(item=>item.menuid==element.menuId)?true:false}  name="menu1" /></h6>
                            <div className="row ">
										{(element.subMenus != undefined && element.subMenus.length > 0) && element.subMenus.map((subitems, ind) => (
											<div className="col-lg-6">
												<div className="submenu-box" key={ind}>
													<label > {subitems.subMenu}
                                                        <input type="checkbox" value={subitems.subMenuId} checked={permission.indexOf(subitems.subMenuId) > -1 ? true : false} onChange={(i)=>handlesubmenus(i,element.menuId)} className="check-menu" name="menu1"/>
													</label>
												</div>
											</div>
										)
										)}
									</div>
                        </div>
                        )}
                        
                        <div className="row md-4">
                            <div className="col-lg-6" >
                               <button className="btn btn-primary" onClick={handlepostuser} style={{marginRight:"9px"}}>Submit</button>
                               <button className="btn btn-warning" onClick={handleLocal}>Clear All</button>

                               <button className="btn btn-danger">Cancel</button>
                           </div>
                            <div className="col-lg-6"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        </div>
        </>
    );
  
}
export default Demo5;