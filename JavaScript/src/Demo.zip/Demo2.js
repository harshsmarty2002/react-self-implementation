import React, { useEffect } from "react";
import {  API,callAPI } from "../../Config/apiUtil";
import { apiUrls } from "../../Config/apiUrl";
import Cookies from "js-cookie";
import { useDispatch ,useSelector} from 'react-redux'
import { errorMessage, successMessage } from '../../Comman/AlertMassge';
import { Sowcatagory } from '../../Redux/Redux/Action/Action';
import { useState } from "react";
import { v4 as uuid } from 'uuid';
import moment from "moment";
import "./demo2.css";
import { rgbToHex } from "@material-ui/core";
import axios from "axios";

// import { type } from "jquery";
// import { Autocomplete } from "@mui/material";

function Demo2() {

  const dispatch=useDispatch();
  // const selector=useSelector();
  let bid=Cookies.get('bid');

  const [cat,setCat]=useState({});
  

  const [valuedata,setValuedata]=useState([]);
  const [itemwise,setItemwise]=useState([]);
  const [gstdisplay,setGstdisplay]=useState([]);
  const _ = require("lodash");
  const [item,setItem]=useState({

    gst:"",
    hsn:"",
    name:"",
    unit:"",
    stock:"",
    summary:"",
    brand:"",
    productcode:"",
    size:"",
    color:"",
  });
  
  const [image, setImage] = useState();
  let [values, setValues] = useState({});
  let [data,setData]=useState([{
    id:"",
    first:"",
    last:"",
    pincode:"",
    state:"",
    address:""
  }]);
  const unique_id = uuid();
  const small_id = unique_id.slice(0,4);
  
  const handlerowfun=()=>{

  const updatearray=[...data,{
      id:small_id,
      first:"",
      last:"",
      pincode:"",
      state:"",
      address:""

    }];
    
      setData(updatearray);
  }
  
  
  const deletebox=(element)=>{
    const checking=data.filter((ele)=>ele!=element);
    console.log(checking);
    setData(checking);
  }

  let [numberArray,setNumberArray]=useState(
    [
      {id:3,first:4,second:5,sum:2},
      {id:4,first:5,second:6,sum:56},
      {id:5,first:6,second:7,sum:67},
      {id:6,first:7,second:8,sum:89},
      {id:7,first:8,second:9,sum:23},
      {id:8,first:9,second:10,sum:90},
    ]
  );

  // const [datas,setDatas]=useState([]);
  let [total, setTotal] = useState({});
  const [signature, setSignature] = useState();
  const [state, setState] = useState([]);
  const [city, setCity] = useState([]);
  const [holder, setHolder] = useState({
    name: "",
    accountNumber: "",
  });

  const handleHolder=async (e) => {
    setHolder({ 
      name: e.target.value
     });
  };
  const [companydata, setCompanydata] = useState({
    address: "",
    tradeName: "",
    city: "",
    ifsc: "",
    branch: "",
    branchname: "",
    bank: "",
    branchcity: "",
  });

  const formbody = {
    CompanyName: companydata.tradeName,
    Address: companydata.address,
    City: companydata.city,
    branch: companydata.branch,
    ifsccode: companydata.ifsc,
    signatureImage: signature ? signature : null,
    LogoImage: image ? image : null,
    bankname: companydata.bank,

    // contactpersonname:'',
    // Mobile:'',
    // Pincode:'',
    // GstIn:'',
    // BusinessType:'',
    // perfitmargin:'',
    // username:'',
    // branchname:'',
    // accountholdername:'',
    // accountno:'',
    // bankname:'',
    // State:'',
    // Cid:'',

  };

  const calling = async (gstval = "") => {
    let query = { gstno: gstval };
    const apiResponse = await callAPI(
      apiUrls.check_company_gstno_existornot,
      query,
      "GET"
    );
    try {
      if (apiResponse.data.value.data == null) {
        setCompanydata({
          address: "",
          tradeName: "",
          city: "",
          pincode: "",
          status: "",
        });
      }
      let details = apiResponse.data.value.data;
      setCompanydata({
        address: `${details.pradr.addr.flno},${details.pradr.addr.st},${details.pradr.addr.loc}`,
        tradeName: details.lgnm,
        city: details.pradr == undefined ? "" : details.pradr.addr.dst,
        pincode: details.pradr == undefined ? "" : details.pradr.addr.pncd,
        status: details.sts,
      });
    } catch (e) {
      console.log(e);
    }
  };

  // const apidata=async()=>{
  //   axios.get("http://hrm.unibillapp.com:8080/api/globalmenus").then((resp)=>{
      
  //   console.log(resp.data.data);
  //   })

  // } //get api

  const apidata=async()=>{
    const query={
      "User":"nehasaini@gmail.com",
      "Password":"Neha@101", 
      "Type":"EmailId" 
    }
    axios.post("http://hrm.unibillapp.com:8080/Api/Login",query).then((resp)=>{
      console.log(resp.data);
    
  });
}

  useEffect(()=>{apidata();},[]);

  const ifscapi = async (ifsc = "") => {
    let query = { ifsccode: ifsc ? ifsc : "" };
    const apiResponse = await callAPI(apiUrls.Get_Ifsc_Detail, query, "GET");
    
    let banking = apiResponse.data.value;
    
    if (
      apiResponse.data.status == "no_record_found" &&
      apiResponse.data.value == null
    ) {
      setCompanydata({
        ifsccode: "",
        branch: "",
        branchname: "",
        bank: "",
        branchcity: "",
      });
    }
    setCompanydata({
      ifsccode: ifsc ? ifsc : "",
      branch: banking ? banking.branch : "",
      branchname: banking ? banking.address : "",
      bank: banking ? banking.bank : "",
      branchcity: banking ? banking.city1 : "",
    });
  };

  function handleKey(e) {
    let special = /^[A-Za-z0-9]+$/i;
    if (e.key.match(special)) {
      return true;
    }
    e.preventDefault();
  }

  function handleIfsc(e) {
    if (e.target.name == "ifsc") {
      let value = e.target.value.toUpperCase();
      let value_two = value.trim();
      ifscapi(value_two);
    }
    // console.log(e);
  }

  function handlechange(e) {
    if (e.target.name == "gstin") {
      let val = e.target.value.toUpperCase();
      let valtri = val.trim();
      // console.log(valtri);
      let r = valtri.length;
      // .trim().toUpperCase();
      if (r > 16) {
        return false;
      }
      if (r == 15) {
        calling(valtri);
        // setvalidclass("is-valid");
      }
      if (r < 15) {
        // setvalidclass("is-invalid");
        setCompanydata({
          address: "",
          tradeName: "",
          city: "",
          pincode: "",
          status: "",
        });
      }
    }
    if (e.target.name == "city") {
      console.log(e.target.value);
      // alert("city");
    }
    if (e.target.name == "address") {
    }
  }
  let formdata = new FormData();
  for (var i in formbody) {
    formdata.append(i, formbody[i]);
  }
  Cookies.set("data", formbody.Address);

  const handleChangeSignature = (e) => {
    if (e.target.files && e.target.files.length > 0) {
      setSignature(e.target.files[0]);
    }
  };

  const handleChangeImage = (e) => {
    if (e.target.files && e.target.files.length > 0) {
      setImage(e.target.files[0]);
      // console.log(e.target.files[0]);
    }
  };

  const callcityapi = async (Stateid = "") => {

    try {
      let query = { stateId: Stateid ? Stateid : "" };
      const apiResponse2 = await callAPI(apiUrls.get_all_city, query, "GET");
      setCity(apiResponse2.data.value);
    } 
    catch (e) {
      console.log(e);
    }

  };

  const handleCity = (e) => {
    callcityapi(e.target.value);
  };

  const callstateapi = async () => {
    try {
      const apiResponse = await callAPI(apiUrls.get_all_state, {}, "GET");
      setState(apiResponse.data.value);
    } 
    catch (e) {
      console.log(e);
    }
  };

  useEffect(() => {
    callstateapi();
  }, []);

  useEffect(() => {
    callstateapi();
  }, []);

  function handleValues(e) {
    if(e.target.name=="sum")
    {
      values["first"]=e.target.value/2;
      values["second"]=e.target.value/2;
    }
    
    setValues((values) => ({ ...values,[e.target.name]: e.target.value }));
  }

  const handlechangeview=(e,id)=>{
    let gets=data.filter((element)=>
    {
      if(element.id==id)
      {
        return element;
      }
    });
    let getslength=gets[0];
    
    let obj={...getslength,[e.target.name]:e.target.value};
    
    let ind=data.findIndex((element)=>{return element.id==id});
    
    data[ind]=obj;
    setData([...data]);
    // setData(({...data,[e.target.name]:e.target.value}));
    // if(e.target.name=="first")
    // {
    //   console.log(e.target.value)
    // }
    
  }
//fundtion for sum input and change to other input boxes
  // function handle(e,id)
  // {
  //  if(numberArray!=undefined && numberArray.length>0)
  //  {
  //   let finds=numberArray.filter((element)=>{
  //     if(element.id==id)
  //     {
  //       return element;
  //     }
  //   })

  //   // console.log(findslength);
  //   if(finds!=undefined && finds.length>0)
  //   {
  //     let findslength=finds[0];
  //     let ind=numberArray.findIndex((r)=>{return r.id==id});
  //     console.log(ind);
  //     let r=e.target.value;
  //     let ful=r/2;
      
  //       // setNumberArray({...numberArray,[e.target.name]:e.target.value});
  //       let obj1={...findslength,["first"]:ful,["second"]:ful,[e.target.name]:e.target.value};
  //       console.log(obj1);
  //       numberArray[ind]=obj1;
  //       setNumberArray([...numberArray]);
  //     // if(e.target.value)
  //     // {
  //     //   let va=parseInt(e.target.value);
  //     //   let correct=va/2;
  //     //   console.log(correct);
  //     //   let obje={...findslength,["first"]:correct,["second"]:correct};
  //     //   console.log(obje);
  //     //   let ind=numberArray.findIndex((r)=>{return r.id==id});
  //     //   console.log(ind);
  //     //   numberArray[ind]=obje;
  //     // }
  //   }
  //  }
   
  // }

  const handleSums = (e,id) => {
    if(numberArray != undefined && numberArray.length>0){
      let findobj = numberArray.filter((cur)=>{
        if(cur.id == id){
          return cur;
        }
         })

      if(findobj != undefined && findobj.length>0){
       let findobjlength = findobj[0];

      let obj = {...findobjlength,[e.target.name]:e.target.value}
      if(e.target.name=="sum"){
        obj.first=Number(e.target.value/2);
        obj.second=Number(e.target.value/2);

      }     
     obj.sum=Number(obj.first)+Number(obj.second);
      let r= numberArray.findIndex((el)=>{return el.id==id});

      numberArray[r]=obj;
      setNumberArray([...numberArray]); 
         } 
    }  
}
const invalidkeys=(e)=>{["e","E","_"].includes(e.key) && e.preventDefault()};
  // console.log(numberArray);
  const array = [
        {bpid: 1134, bid: '0912211950b01', partyName: 'THE KARNATAKA BANK LIMITED', companyname: 'THE KARNATAKA BANK LIMITED', gstin: '37AABCT5589K2ZN'},
        {bpid: 2129, bid: '0912211950b01', partyName: 'DELHI METRO RAIL CORPORATION LIMITED', companyname: 'Atoz', gstin: '06AAACD3254A1DM'},
        {bpid: 2134, bid: '0912211950b01', partyName: 'V MART RETAIL LIMITED', companyname: 'V MART RETAIL LTD', gstin: '06AABCV7206K1Z9'},
        {bpid: 2135, bid: '0912211950b01', partyName: 'OSGAN CONSULTANTS PVT LTD', companyname: 'OSGAN CONSULTANTS PVT.LTD', gstin: '07AAACO4986A1ZJ'},
        {bpid: 2152, bid: '0912211950b01', partyName: 'UJJIVAN SMALL FINANCE BANK LIMITED', companyname: 'UJJIVAN SMALL FINANCE BANK LIMITED', gstin: '18AABCU9603R1ZM'},
        {bpid: 2220, bid: '0912211950b01', partyName: 'UJJIVAN SMALL FINANCE BANK LIMITED', companyname: 'UJJIVAN SMALL FINANCE BANK LIMITED', gstin: '22AABCU9603R1ZX'},
        {bpid: 2520, bid: '0912211950b01', partyName: 'dfdsf', companyname: 'skjdsaf', gstin: 'URP'},
  ];

  const [unit,setUnit]=useState([]);
  const unitapi=async()=>{
    try{
      const apiResponse = await callAPI(apiUrls.get_all_units, {}, "GET");
      
      setUnit(apiResponse.data.value);
      
    }
    catch(error){
      console.log(error);

    }
    
  }
  useEffect(()=>{unitapi();},[]);


  const handlegst=(e)=>{

    setItem({...item,[e.target.name]:e.target.value});
  }
  const handlekeysfun=(e)=>{

    if(e.target.name=="name")
    {
      let special = /^[A-Za-z0-9-_]+$/i;
      if(e.key.match(special))
      {
        return true;
      }
      e.preventDefault();
    }
    if(e.target.name=="hsn")
    {
      let special = /^[0-9]+$/i;
      if(e.key.match(special))
      {
        return true;
      }
      e.preventDefault();

    }
    if(e.target.name=="summary")
    {
      let special = /^[A-Za-z0-9-_]+$/i;
      if(e.key.match(special))
      {
        return true;
      }
      e.preventDefault();
    }
    if(e.target.name=="color")
    {
      let special = /^[A-Za-z]+$/i;
      if(e.key.match(special))
      {
        return true;
      }
      e.preventDefault();
    }
  }
const allgst=()=>{

if(gstdisplay!=undefined && gstdisplay.length>0)
{
  let found=gstdisplay.filter((value)=>{
    if(value.sn==item.gst)
    {
      return value;
    }
     });
     let foundlength=found[0];
     if(foundlength!=undefined && foundlength.length>0)
     {
      setItemwise(foundlength);
     }
}
  }
  
  useEffect(()=>{allgst();},[]);

  const form={
    productname: item.name,
    hnscode: item.hsn ? parseInt(item.hsn) : "",
    unitid: item.unit,
    igst: itemwise.igst != null ? itemwise.igst : 0,
    cgst: itemwise.cgst != null ? itemwise.cgst : 0,
    sgst: itemwise.sgst != null ? itemwise.sgst : 0,
  }

  const forms=new FormData();
  for(var i in form)
  {
    forms.append(i,form[i]);
  } 

  const submitdata=async()=>{
    try{

      const apiResponse = await API(apiUrls.create_product, {}, "POST", forms);

      console.log(apiResponse.data.status);
    }
    catch(error){
      console.log(error);
    }

  }

  const allgstdisplay=async()=>{
    const apiResponse = await callAPI(apiUrls.gst_rate_dsiplay, {}, "GET");
    
    setGstdisplay(apiResponse.data.value)

  }
  useEffect(()=>{allgstdisplay();},[]);

  const cancelmodal=()=>{

    setItem({
      
    gst:"",
    hsn:"",
    name:"",
    unit:"",
    stock:"",
    summary:"",
    brand:"",
    productcode:"",
    size:"",
    color:"",
    });
  }

  const handledrop=()=>{
    console.log()
  }

  const fill=async(value)=>{
    let query = { bid:bid, q:value}
    //console.log(query);
    const apiResponse = await callAPI(apiUrls.search_category_subcategory, query, "GET");
    // console.log(Object.key(apiResponse.data));
    if(apiResponse.data.value!=null && apiResponse.data.value.length>0)
    {
      console.log(apiResponse.data.value);
      setValuedata(apiResponse.data.value);
    }
    else{
      setValuedata([]);
    }    
  }

  const editcat=(e,id)=>{
    
    let found=valuedata.filter((value)=>{return value.sno==id});
    let foundlength=found[0];

    console.log(foundlength);

    let findind=valuedata.findIndex((values)=>{return values.sno==id});
    let obj={...foundlength,["categoryname"]:e.target.value};

    valuedata[findind]=obj;
    setValuedata([...valuedata]);
    setCat((val)=>({...val,['sno']:id,["categoryname"]:e.target.value}));
  }

  const data1={
        categoryname: cat.categoryname,
        sno: cat.sno,
	      bid : bid
  }

  // console.log(cat);

  const categoryapi=async()=>{
    const apiResponse = await callAPI(apiUrls.create_category_subcategory, {}, "POST", data1);
    if(apiResponse.data.status=="update_successfully")
    {
      console.log("Done");
    }
  }

  function posting()
  {
    categoryapi();
  }

  const displaycategory=async()=>{
    let query={bid:bid}
		   const apiResponse = await callAPI(apiUrls.category_subcategory_display,query, "GET");
      //  console.log(apiResponse.data.value);
       if(apiResponse.data.value!=undefined && apiResponse.data.value!=null)
       {
        dispatch(Sowcatagory(apiResponse.data.value));
        setValuedata(apiResponse.data.value);

       }
  }
  useEffect(()=>{displaycategory();},[]);

  const cancelButton=()=>{
   
    // setValuedata({...valuedata})
    
  }

  // const totalsum=values2.reduce((cur,elm)=>cur+elm.+elm,0);
  // console.log(totalsum);
  // console.log(valuedata);
 
  return (
    <>
    <div className="dashboard_body_content add_item_bg">
      <div className="dashboard_container container">
        <div className="row row_div">
          {/* <div>
            {datas.map((ele,ind)=>
            <table>
              <tr>
                <th></th>
              </tr>
            </table>)}

          </div> */}
            <div className="col-lg-2">
                  <label>Add category</label>
            </div>
            <div className="col-lg-10">
              <div className="input-group">
                  <input type="text" className="form-control" placeholder="Enter Category Name"/>
                  <button className="input-type-text btn btn-primary">Add Category</button> 
              </div>
            </div>
            <div>
              <div className="input-group">
              <div className="input-group-prepend">
              <i className="fa-solid fa-magnifying-glass "></i>
              <span><i className="fa-regular fa-magnifying-glass"></i></span>
              </div>
             
              <input type="text" placeholder="Enter Searching Category Here" onChange={(e)=>fill(e.target.value)} className="form-control"/> 

              </div>
          
            </div>
                {valuedata.map((val,ind)=>(
                  <h6 key={ind}>
                    <div className="row" style={{backgroundColor:"#F0F3F4",marginTop:"15px",padding:"5px",borderRadius:"8px",border:"1px solid #283593"}}>
                    <div className="row" style={{marginTop:"12px"}}>
                     <div className="col-lg-3">
                     <div className="input-group">

                     <input type="text"  className="form-control" onChange={(e)=>editcat(e,val.sno)} value={val.categoryname} name="category"/>
                     {cat!=undefined ?<button className="btn btn-danger input-group-text" onClick={cancelButton}>Cancel</button>:""}
                     </div>
                     </div>
                     <div className="col-lg-6">
                     <div style={{marginTop:"10px"}}><img src="/image/small-edit.png" alt="edit" />Edit</div>
                     </div>
                     <div className="col-lg-3">
                     <img src="/image/Folder.png" alt="folder"/>
                     <button className="btn btn-warning" style={{float:"right"}} onClick={posting}>Update</button>
                     </div>
                      </div>
                      <div className="row" style={{marginTop:"12px",marginBottom:"12px"}}>
                        <div className="col-lg-2">
                          <button style={{textAlign:"center",fontSize:"10px"}} className="btn btn-secondary">Add/Edit <br/> Category and subcategory</button>
                        {/* <input type="text" value={val.categoryname}  className="form-control"/>                           */}
                        </div>
                        <div className="col-lg-10">
                          

                        </div>
                    </div>
                    </div>                    
                  </h6>
                )
                  )}
           
        </div>
      </div>
    </div>
    <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog container modal-dialog-centered modal-lg" style={{maxWidth:"95%"}} role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Add New Item</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <div className="row ">
        <div className="col-lg-3">
            <div>
            <label>Item Name</label>
            <input type="text" placeholder="Enter Item Name here" maxLength={30} onKeyPress={handlekeysfun} value={item.name}  onChange={handlegst} name="name" className="form-control"/>
            </div>
          </div>
        
          <div className="col-lg-3">
            <div>
            <label>Item Summary</label>
            <input type="text" placeholder="Enter Item summary"  onKeyPress={handlekeysfun} value={item.summary}  onChange={handlegst} name="summary" className="form-control"/>
            </div>
          </div>
          <div className="col-lg-3">
            <div>
            <label>Brand/Company</label>
            <input type="text" placeholder="Enter Brand/Company" name="brand" maxLength={30} onKeyPress={handlekeysfun} value={item.brand}  onChange={handlegst}  className="form-control"/>
            </div>
          </div>
          <div className="col-lg-3">
            <div>
            <label>Item/Product Code</label>
            <input type="text" placeholder="Enter Item/Product Code" maxLength={30} onKeyPress={handlekeysfun} value={item.productcode}  onChange={handlegst} name="productcode" className="form-control"/>
            </div>
          </div>
          </div>
          <div className="row">
            <div className="col-lg-3">
              
             <label>Size</label>
              <input type="text"  value={item.size}  onChange={handlegst} name="size" className="form-control"/>

            </div>
            <div className="col-lg-3">
              <label>Color</label>
              <input type="text"  value={item.color}  onChange={handlegst} name="color" className="form-control"/>
            </div>
            <div className="col-lg-3">
              <label>Purchase Price</label>
              <div className="input-group">
                <input type="text" className="form-control"/>
                <select className="input-group-text form-select" name="purchaseprice" onChange={handledrop}>
                  <option>Exclusive</option>
                  <option>Inclusive</option>
                </select>
              </div>
            </div>
            <div className="col-lg-3">
              <label>Sales Price</label>
              <div className="input-group">
                <input type="text" className="form-control"/>
                <select className="input-group-text form-select" name="salesprice" onChange={handledrop}>
                  <option>Exclusive</option>
                  <option>Inclusive</option>
                </select>
              </div>
            </div>
          </div>
          <div className="row">
            <div className="col-lg-3">
            <label>Unit<span style={{color:"red",fontSize:"small"}}>Required *</span></label>
            <select className="form-select"  value={item.unit} name="unit" onChange={handlegst}>
              <option>select</option>
              {unit!=undefined && unit.length>0 && unit.map((val,index)=>
              <option key={index} value={val.sno} selected={item.unit==val.unitvalue?true:false}>{`${val.unitname},${val.unitvalue}`}</option>)}
            </select>
            </div>
            <div className="col-lg-3">
            <label>HSN Code</label>
            <input type="number" placeholder="Enter Hsn code here" maxLength={10} onKeyPress={handlekeysfun} value={item.hsn}  onChange={handlegst} name="hsn" className="form-control"/>

            </div>
            <div className="col-lg-3">
            <label>Gst %</label>
            <select className="form-select" name="gst"  onChange={handlegst}>
              <option >select</option>
              {gstdisplay!=undefined && gstdisplay.length>0 && gstdisplay.map((val,ind)=>
              <option key={ind} value={val.sn} selected={val.igst==item.gst?true:false}>{val.igst}</option>)
              }
            </select>

            </div>
            <div className="col-lg-3">
              <label>Batch Number</label>
              <input type="number" className="form-control"/>

            </div>

          </div>
          <div className="row">
            <div className="col-lg-3">
              <label>Size</label>
              <input type="number" className="form-control"/>

            </div>
            <div className="col-lg-3">
              <label>Stock Quantity as of</label>
              <input type="date" max={moment(new Date()).format("DD-MM-YYYY")} className="form-control"/>

            </div>
            <div className="col-lg-3">
              <label>Expiry in </label>
              <input type="date" className="form-control"/>

            </div>
            <div className="col-lg-3">
              <label>Description</label>
              <textarea type="text" className="form-control"/>

            </div>
          </div>
      </div>
      <div class="modal-footer">
      
        <button type="button" class="btn btn-secondary" name="cancel" onClick={cancelmodal} data-dismiss="modal">Close</button>
        {item.value=="" ?
        <button type="button" class="btn btn-primary disabled" aria-disabled="true">Submit</button>
        :
        <button type="button" class="btn btn-primary" onClick={submitdata}>Submit</button>
        }

      </div>
    </div>
  </div>
</div>


<div class="modal fade" id="exampleModalCenter" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLongTitle">Modal title</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        ...
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary">Save changes</button>
      </div>
    </div>
  </div>
</div>
  {/* <div className="modal fade" id="exampleModalsecond" role="dialog" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                <div className="modal-dialog modal-dialog-centered addnew_item">
                    <div className="modal-content">
                        <div className="modal-header">
                            <h5 className="modal-title" id="exampleModalLabel"><i className="fa fa-file-text-o me-2" aria-hidden="true"></i> Add New Item</h5>
                            <button type="button" className="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div className="modal-body">
                            <div className="row">
                                <div className="product_details mt-0">
                                    <div className="row product_form">
                                        <div className="col-lg-4">
                                            <div className="form-group">
                                                <label>Item/Product name </label>
                                                <input type="text"  name="productname" className="form-control" placeholder="Enter product name" />
                                            </div>
                                        </div>
                                        <div className="col-lg-4">
                                            <label>Purchase Price </label>
                                            <div className="form-group position-relative input-group border-input">
                                                <input type="number" min="0" onWheel={() => document.activeElement.blur()}   name="priceperunit" className="form-control" placeholder="Enter Purchase Price" />
                                                <select className='form-select' name="incgst">
                                                    <option value="Exclusive">Exclusive GST</option>
                                                    <option value="Inclusive">Inclusive GST</option>
                                                </select>
                                            </div>
                                        </div>
                                        <div className="col-lg-4">
                                            <label>Sales Price </label>
                                            <div className="form-group position-relative input-group border-input">
                                                <input type="number" name='saleprice' min="0" onWheel={() => document.activeElement.blur()}  value={sales.saleprice} onChange={handlesalesChange} className="form-control" placeholder="Enter Sales Price" />
                                                <select className='form-select'>
                                                    {
                                                        addItem.incgst == "Inclusive" ?
                                                            <option value="Inclusive" selected>Inclusive GST</option> :
                                                            addItem.incgst == "Exclusive" &&
                                                            <option value="Exclusive" selected>Exclusive GST</option>

                                                    }
                                                </select>
                                            </div>
                                        </div>
                                        <div className="col-lg-4">
                                            <div className="form-group">
                                            <label>Unit <sup>*</sup>{((addItem.unitid == "select") || (!addItem.unitid)) &&<div className="error_msg">Required</div>} </label>
                                                <select className="form-select" name="unitid">
                                                    <option value="select">select a Unit</option>
                                                    {allUnit != undefined && allUnit.length > 0 && allUnit.map((value, i) => (
                                                        <option key={i} value={value.sno} selected={value.sno == addItem.unitid ? true : false }>{value.unitname}({value.unitvalue})</option>
                                                    ))}
                                                </select>
                                            </div>
                                        </div>
                                        <div className="col-lg-4">
                                            <div className="form-group">
                                                <label>HSN Code{!addItem.hnscode &&<div className="error_msg">Required</div>}</label>
                                                <input type="number" min="0" onWheel={() => document.activeElement.blur()} onKeyDown={blockInvalidCharpoint} value={addItem.hnscode} name='hnscode' className="form-control" placeholder="Enter HSN Code" />
                                            </div>
                                        </div>
                                        <div className="col-lg-4">
                                            <div className="form-group">
                                                <label>GST%</label>
                                                <select className="form-select" onChange={(e) => changeSelectOptionHandler(e)} >
                                                    {(gstdisplayitem != undefined && gstdisplayitem.length > 0) && gstdisplayitem.map((val, ind) => (
                                                        <option value={val.igst} selected={val.igst == ItemWisegst.igst ? true : false}>{val.igst}</option>
                                                    ))}
                                                </select>
                                            </div>
                                        </div>
                                        <div className="col-lg-4">
                                            <div className="form-group">
                                                <label>Stock quantity</label>
                                                <input type="number" min="0" onWheel={() => document.activeElement.blur()}  className="form-control" value={addItem.stockavailable} name="stockavailable" placeholder="Quantity" />
                                            </div>
                                        </div>
                                        <div className="col-lg-8">
                                            <div className="form-group">
                                                <label>Description</label>
                                                <textarea className="form-control" rows="2"  name="productdetails" placeholder="Enter product description"></textarea>
                                            </div>
                                        </div>
                                        <div className="col-lg-12">
                                            <div className="form-group add_categ_button mt-2 d-block">
                                            
                                                <button type='submit'  className="btn button_save text-white me-4" disabled>Save</button>:
                                                <button type='submit'  className="btn button_save text-white me-4" data-bs-dismiss="modal" aria-label="Close">Save</button>
                                            

                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div> */}
    
      <div className="dashboard_body_content add_item_bg">
        <div className="dashboard_container">
          <div className="container form-group">
            <div className="row row_div">
           <div className="col-lg-6">
           </div>      
            <div className="col-lg-6">
                  <button type="button" class="btn btn-warning" data-toggle="modal" data-target="#exampleModalCenter">
                    Launch demo modal
                  </button>
                  <button type="button" class="btn btn-danger" data-toggle="modal" data-target="#exampleModal">
                    Add Item 
                  </button>
            </div>
              </div>
              
              <div className="row row_div">
              <button onClick={handlerowfun} className="btn btn-primary btn-md wd-80">+ Click this button</button>
              {data.map((element,index)=>(
                 <div className="row" key={index}>
                 <div className="col-lg-2">
                  <label>First Name</label>
                  <input type="text" value={element.first} name="first"  className="form-control"/>
                 </div>
                 <div className="col-lg-2">
                  <label>Last Name</label>
                  <input type="text" value={element.last} name="last"  className="form-control"/>
                 </div>
                 <div className="col-lg-2">
                  <label>Pincode</label>
                  <input type="text" value={element.pincode} name="pincode"  className="form-control"/>
                 </div>
                 <div className="col-lg-2">
                  <label>State</label>
                  <input type="text" value={element.state} name="state"  className="form-control"/>
                 </div>
                 <div className="col-lg-2">
                  <label>Address</label>
                  <textarea value={element.address} name="address"  className="form-control" rows={1} />
                 </div>
                 <div className="col-lg-2">
                 {index==0?"":<div onClick={(e)=>deletebox(element)} type="button"><strong style={{color:"red"}}>CANCEL</strong></div>}
                  </div>
                  </div>
              ))}
                </div>
                
                      {/* <Autocomplete
                      items={array}
                      renderItem={(item,value)=><div>
                        {item.}
                        </div>}
                      // renderItem={(item, isHighlighted) =>
                      //   <div style={{ background: isHighlighted ? 'lightgray' : 'white' }}>
                      //     {item.label}
                      //   </div>
                      // }
                      // value={value}
                      // onChange={(e) => value = e.target.value}
                      // onSelect={(val) => value = val}
                    /> */}         
            <div className="row row_div">
              <table>
              {numberArray.map((r,ind)=>
              <tr key={ind}>
              <th>
                <lable>First</lable>
                <input
                  type="number"
                  value={r.first}
                  onChange={(e)=>handleSums(e,r.id)}
                  onKeyDown={invalidkeys}
                  name="first"
                  className="form-control"
                />
              </th>
              <th>
                <lable>Second</lable>
                <input
                  type="number"
                  value={r.second}
                  onChange={(e)=>handleSums(e,r.id)}
                  name="second"
                  className="form-control"
                />
              </th>
              <th>
                <lable>Sum</lable>
                <input
                  type="number"
                  value={r.sum}
                  onChange={(e)=>handleSums(e,r.id)}
                  // value={val}
                  name="sum"
                  className="form-control"
                />
              </th>
            </tr>)}
              </table>
            </div>
            <div className="row row_div ">
              <div className="col-lg-4">
                <div className="was-validated">
                  <label>GstIn</label>
                  <input
                    type="text"
                    className={"form-control"}
                    placeholder="enter gst here"
                    // value={}
                    name="gstin"
                    maxLength={16}
                    onKeyPress={handleKey}
                    onChange={handlechange}
                    required
                  />
                </div>
              </div>
              <div className="col-lg-4">
                <div>
                  <label>Trade Name</label>
                  <input
                    type="text"
                    // value={trade.tr}
                    value={companydata.tradeName}
                    readOnly={true}
                    className="form-control"
                    placeholder="Tradename here"
                    onChange={(e) => handlechange(e)}
                    name="city"
                  />
                </div>
              </div>
              <div className="col-lg-4">
                <div>
                  <label>Address</label>
                  <textarea
                    placeholder="Address here"
                    // value={add.address}
                    value={companydata.address}
                    readOnly={true}
                    onChange={(e) => handlechange(e)}
                    name="address"
                    className="form-control"
                  />
                </div>
              </div>
              <div className="col-lg-4">
                <div>
                  <label>City</label>
                  <input
                    type="text"
                    value={companydata.city}
                    readOnly={true}
                    className="form-control"
                    placeholder="city here"
                    onChange={(e) => handlechange(e)}
                    name="city"
                  />
                </div>
              </div>
              <div className="col-lg-4">
                <div>
                  <label>Status</label>
                  <input
                    type="text"
                    value={companydata.status}
                    readOnly={true}
                    className="form-control"
                    placeholder="Status here"
                    onChange={(e) => handlechange(e)}
                    name="city"
                  />
                </div>
              </div>
              <div className="col-lg-4">
                <div>
                  <label>Pincode</label>
                  <input
                    type="text"
                    value={companydata.pincode}
                    readOnly={true}
                    className="form-control"
                    placeholder="Pincode here"
                    onChange={(e) => handlechange(e)}
                    name="city"
                  />
                </div>
              </div>
            </div>
            <div className="row row_div">
              <div className="col-lg-6">
                <div>
                  <label>Select State</label>
                  <select className="form-control" onChange={handleCity}>
                    {state.map((r, ind) => (
                      <option key={ind} value={r.stateId}>
                        {r.stateName}
                      </option>
                    ))}
                  </select>
                </div>
              </div>
              <div className="col-lg-6">
                <label>City</label>
                <select className="form-control">
                  {city.map((r, ind) => (
                    
                    <option key={ind}>{r.cityName}</option>

                  ))}
                </select>
              </div>
            </div>
            <div className="row row_div">
              <div className="col-lg-4">
                <label>IFSC Code</label>
                <input
                  type="text"
                  className="form-control"
                  maxLength={11}
                  name="ifsc"
                  onChange={(e) => handleIfsc(e)}
                  placeholder="Enter Ifsc Code here"
                />
                <div className="invalid-feedback">
                  Can't be blank or incorrect.....
                </div>
              </div>
              <div className="col-lg-4">
                <label>Bank Name</label>
                <input
                  type="text"
                  className="form-control"
                  name="bank"
                  value={companydata.bank}
                  onChange={(e) => handleIfsc(e)}
                  placeholder="Bank Name here"
                />
              </div>
              <div className="col-lg-4">
                <label>Branch Name</label>
                <input
                  type="text"
                  className="form-control"
                  name="branch"
                  value={companydata.branchname}
                  onChange={(e) => handleIfsc(e)}
                  placeholder="Branch here"
                />
              </div>
              <div className="col-lg-4">
                <label>Account Holder Name</label>
                <input
                  type="text"
                  className="form-control"
                  value={holder.name}
                  onChange={(e) => setHolder({ ...e, name: e.target.value })}
                  placeholder="Enter Ifsc Code here"
                />
              </div>
              <div className="col-lg-4">
                <label>Account Number</label>
                <input
                  type="text"
                  className="form-control"
                  value={holder.accountNumber}
                  onChange={(e) =>
                    setHolder({ ...e, accountNumber: e.target.value })
                  }
                  placeholder="city here"
                />
              </div>
              <div className="col-lg-4">
                <label>Branch Address</label>
                <textarea
                  className="form-control"
                  value={companydata.branch}
                  onChange={(e) => handleIfsc(e)}
                  rows="3"
                  placeholder="Enter Ifsc Code here"
                />
              </div>
            </div>
            <div className="row row_div">
              <div className="col-lg-4">
                <div className="image_div">
                  <div type="button">
                    <input
                      type="file"
                      accept="image/png, image/jpeg"
                      alt="logo"
                      placeholder="select Image here"
                      onChange={handleChangeImage}
                      onClick={(e) => e.target.value == null}
                    />
                    
                    {image ? (
                      <img
                        src={URL.createObjectURL(image)}
                        height="60px"
                        width="60px"
                      />
                    ) : (
                      <i class="fa fa-camera" style={{ paddingTop: "40%" }}></i>
                    )}

                  </div>

                  <div type="button">
                    <input
                      type="file"
                      accept="image/png, image/jpeg"
                      alt="logo"
                      placeholder="select Image here"
                      onChange={handleChangeSignature}
                      onClick={(e) => e.target.value == null}
                    />
                    {signature ? (
                      <img
                        src={URL.createObjectURL(signature)}
                        height="60px"
                        width="60px"
                      />
                    ) : (
                      <i class="fa fa-camera" style={{ paddingTop: "40%" }}></i>
                    )}
                  </div>
                </div>
              </div>
              {/* <input type="file" className="form-control" placeholder="Enter Ifsc Code here"/> */}
              <div className="col-lg-4"></div>
              <div className="col-lg-4">
                <button
                  className="btn btn-primary btn-sm"
                  style={{ position: "absolute", bottom: "0px", right: "90px" }}
                  // onClick={(e)=>handlePost(e)}
                >
                  Submit
                </button>
                <button
                  className="btn btn-secondary btn-sm"
                  style={{ position: "absolute", bottom: "0px", right: "10px" }}
                >
                  Cancel
                </button>
              </div>
            </div>
            <div className="row row_div">
              <div className="col-lg-4">
                <label>First Value</label>
                <input
                  type="number"
                  className="form-control"
                  value={values.first}
                  onChange={handleValues}
                  name="first"
                  placeholder="Enter First Value"
                />
              </div>
              <div className="col-lg-4">
                <label>Second Value</label>
                <input
                  type="number"
                  className="form-control"
                  value={values.second}
                  onChange={handleValues}
                  name="second"
                  placeholder="Enter Second Value"
                />
              </div>

              <div className="col-lg-4">
                <label>Sum of Value</label>
                <input
                  type="number"
                  className="form-control"
                  onChange={handleValues}
                  value={Number(values.first)+Number(values.second)}
                  name="sum"
                  placeholder="Enter Third Value"
                />
              </div>
            </div>

            <div className="row row_div">
              <div className="row">
                {/* <div className="col-md-4">
                  <div className="form-group">
                    <lable>Fist</lable>
                    <input
                      type="text"
                      value={values2.first}
                      onChange={handleSums}
                      name="first"
                      className="form-control"
                    />
                  </div>
                </div>
                <div className="col-md-4">
                  <div className="form-group">
                    <lable>Second</lable>
                    <input
                      type="text"
                      value={values2.second}
                      onChange={handleSums}
                      name="second"
                      className="form-control"
                    />
                  </div>
                </div> */}
                {/* <div className="col-md-4">
                  <div className="form-group">
                    <lable>Sum</lable>
                    <input
                      type="text"
                      value={Number(values2.first) + Number(values2.second)}
                      className="form-control"
                    />
                  </div>
                </div> */}
              </div>

              <div className="col-md-4">
                {/* <label>Total  -{totalsum}.00</label> */}
                {/* {array.map((r)=>(
                  <input type="text" value={Number(r.sum)} className="form-control" />
                ))} */}
              </div>
              {/* <button onClick={sum}>Click</button> */}
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
export default Demo2;
