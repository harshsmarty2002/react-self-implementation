import React, { useEffect, useState } from "react";
import axios from "axios";
const Axios = () => {
    
    let[product,setProduct] = useState([]);
    async function getdata(){   
        axios.get("https://api.webroot.net.in/products.php").then((result)=>{
            setProduct(result.data);
    
            
        })}


    useEffect(()=>{getdata();},[]);
        
    return (
        <div>
            <button className="btn btn-primary" >Check</button>
            {/* <input type="text" className="form-control" value={data} ></input>
             */}
             {product.map((r)=>
             <img src={r.photo}/>)
             }

        </div>
    );
}
export default Axios;
