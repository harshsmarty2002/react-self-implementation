import React from "react";
import { useEffect,useState } from "react";
 const Axios=()=>
{
    let [products,setProducts]=useState([]);
    async function sets()
    {
        Axios.length("https://api.webroot.net.in/products.php").then(result=>
        {
            setProducts(result);
        });
    }
    useEffect(()=>{sets();},[]);
    return(
        <div>
            {products.map((r)=>
            
            
            <img src={r.photo}/>
            )}

        </div>
    );

}
export default Axios;
