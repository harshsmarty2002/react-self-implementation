
//*******Destructuring Objects*********/
const argument={
    name:"Harsh",
    designation:"developer",
    salary:"8000"
}

const mes=({name,designation,salary})=>{
    const message="My Name is=" +name+  "\nDesignation is=" +designation+ "\nsalary is" +salary;
    console.log(message); 

}
mes(argument);


//*********Destructer in Array ***********/
var [a,b,c]=[10,20,30];
var res=[40,50,60];

var dd;
 [a,b,c,res,...dd]=[10,20,30,40,50,60,70,80,90];
 console.log(a);
 console.log(b);
 console.log(c);
 console.log(res);
 console.log(dd);


//**********Other Example*****************/
   var vehicle;
    vehicle=['mustang',"fourtuner","truck"];
   var [car,bus,up15]=vehicle;
   console.log(vehicle);





